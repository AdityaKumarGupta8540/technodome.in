/**
 * OLX Authentication Module
 * Handles Login, Registration, Password Reset, Profile Data, and LocalStorage auth state.
 */

const Auth = {
  getCurrentUser() {
    return window.DataStore.getCurrentUser();
  },

  isLoggedIn() {
    return !!this.getCurrentUser();
  },

  login(email, password) {
    if (!email || !password) {
      return { success: false, message: 'Please enter both email and password.' };
    }

    // Demo authentication check
    const user = {
      id: 'usr-' + Date.now().toString(36),
      name: email.split('@')[0].toUpperCase(),
      email: email,
      phone: '+91 98200 ' + Math.floor(10000 + Math.random() * 90000),
      memberSince: 'August 2026',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      location: 'Mumbai, Maharashtra',
      verified: true
    };

    window.DataStore.setCurrentUser(user);
    if (window.App && window.App.showToast) {
      window.App.showToast(`Welcome back, ${user.name}!`, 'success');
    }
    return { success: true, user };
  },

  register(name, email, phone, password) {
    if (!name || !email || !password) {
      return { success: false, message: 'Please fill in all required fields.' };
    }

    const newUser = {
      id: 'usr-' + Date.now().toString(36),
      name: name,
      email: email,
      phone: phone || '+91 98000 00000',
      memberSince: 'August 2026',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      location: 'Bengaluru, Karnataka',
      verified: true
    };

    window.DataStore.setCurrentUser(newUser);
    if (window.App && window.App.showToast) {
      window.App.showToast(`Account created successfully! Welcome, ${newUser.name}.`, 'success');
    }
    return { success: true, user: newUser };
  },

  logout() {
    window.DataStore.setCurrentUser(null);
    if (window.App && window.App.showToast) {
      window.App.showToast('You have been logged out.', 'info');
    }
    // Refresh page or redirect to home if on protected page
    if (window.location.pathname.includes('profile.html') || window.location.pathname.includes('sell.html')) {
      window.location.href = window.App.getBasePath() + 'index.html';
    }
  },

  updateProfile(updatedData) {
    const user = this.getCurrentUser();
    if (!user) return { success: false, message: 'User not logged in' };

    const newUser = { ...user, ...updatedData };
    window.DataStore.setCurrentUser(newUser);
    if (window.App && window.App.showToast) {
      window.App.showToast('Profile updated successfully!', 'success');
    }
    return { success: true, user: newUser };
  }
};

window.Auth = Auth;
