/**
 * OLX Marketplace Data Store
 * Provides categories, subcategories, seed listings, locations, and localStorage syncing.
 */

const STORAGE_KEYS = {
  LISTINGS: 'olx_listings',
  WISHLIST: 'olx_wishlist',
  CURRENT_USER: 'olx_current_user',
  USERS: 'olx_users',
  RECENT_SEARCHES: 'olx_recent_searches',
  CHATS: 'olx_chats',
  NOTIFICATIONS: 'olx_notifications'
};

// 13 Major Categories & their respective subcategories and metadata
const CATEGORIES_DATA = [
  {
    id: 'real-estate',
    name: 'Real Estate',
    slug: 'real-estate',
    icon: 'fa-solid fa-building',
    banner: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80',
    description: 'Find homes, plots, rental properties, office spaces, and commercial buildings.',
    subcategories: [
      { id: 'residential-property', name: 'Residential Property', icon: 'fa-solid fa-house' },
      { id: 'commercial-property', name: 'Commercial Property', icon: 'fa-solid fa-city' },
      { id: 'flats-apartments', name: 'Flats & Apartments', icon: 'fa-solid fa-building' },
      { id: 'land-plots', name: 'Land & Plots', icon: 'fa-solid fa-layer-group' },
      { id: 'rental-property', name: 'Rental Property', icon: 'fa-solid fa-key' },
      { id: 'pg-hostel', name: 'PG & Hostel', icon: 'fa-solid fa-bed' },
      { id: 'office-space', name: 'Office Space', icon: 'fa-solid fa-briefcase' },
      { id: 'warehouses', name: 'Warehouses', icon: 'fa-solid fa-warehouse' }
    ]
  },
  {
    id: 'vehicles',
    name: 'Vehicles',
    slug: 'vehicles',
    icon: 'fa-solid fa-car',
    banner: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
    description: 'Buy & sell cars, motorbikes, scooters, commercial trucks, spare parts, and EVs.',
    subcategories: [
      { id: 'cars', name: 'Cars', icon: 'fa-solid fa-car-side' },
      { id: 'bikes', name: 'Bikes', icon: 'fa-solid fa-motorcycle' },
      { id: 'scooters', name: 'Scooters', icon: 'fa-solid fa-moped' },
      { id: 'commercial-vehicles', name: 'Commercial Vehicles', icon: 'fa-solid fa-van-shuttle' },
      { id: 'trucks', name: 'Trucks', icon: 'fa-solid fa-truck-moving' },
      { id: 'auto-rickshaw', name: 'Auto Rickshaw', icon: 'fa-solid fa-car-on' },
      { id: 'electric-vehicles', name: 'Electric Vehicles', icon: 'fa-solid fa-charging-station' },
      { id: 'spare-parts', name: 'Spare Parts', icon: 'fa-solid fa-gears' }
    ]
  },
  {
    id: 'jobs',
    name: 'Jobs',
    slug: 'jobs',
    icon: 'fa-solid fa-briefcase',
    banner: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=1200&q=80',
    description: 'Explore full-time, part-time, remote, internship, and freelance opportunities.',
    subcategories: [
      { id: 'full-time-jobs', name: 'Full-Time Jobs', icon: 'fa-solid fa-business-time' },
      { id: 'part-time-jobs', name: 'Part-Time Jobs', icon: 'fa-regular fa-clock' },
      { id: 'work-from-home', name: 'Work From Home', icon: 'fa-solid fa-laptop-house' },
      { id: 'freelance-jobs', name: 'Freelance Jobs', icon: 'fa-solid fa-laptop-code' },
      { id: 'internships', name: 'Internships', icon: 'fa-solid fa-graduation-cap' },
      { id: 'government-jobs', name: 'Government Jobs', icon: 'fa-solid fa-landmark' },
      { id: 'recruitment-services', name: 'Recruitment Services', icon: 'fa-solid fa-user-tie' }
    ]
  },
  {
    id: 'electronics',
    name: 'Electronics',
    slug: 'electronics',
    icon: 'fa-solid fa-mobile-screen',
    banner: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80',
    description: 'Smartphones, laptops, gaming computers, tablets, cameras, and wearable tech.',
    subcategories: [
      { id: 'mobile-phones', name: 'Mobile Phones', icon: 'fa-solid fa-mobile-screen-button' },
      { id: 'laptops', name: 'Laptops', icon: 'fa-solid fa-laptop' },
      { id: 'computers', name: 'Computers', icon: 'fa-solid fa-desktop' },
      { id: 'tablets', name: 'Tablets', icon: 'fa-solid fa-tablet-screen-button' },
      { id: 'cameras', name: 'Cameras', icon: 'fa-solid fa-camera' },
      { id: 'smart-watches', name: 'Smart Watches', icon: 'fa-solid fa-stopwatch' },
      { id: 'accessories', name: 'Accessories', icon: 'fa-solid fa-headphones' }
    ]
  },
  {
    id: 'home-furniture',
    name: 'Home & Furniture',
    slug: 'home-furniture',
    icon: 'fa-solid fa-couch',
    banner: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=80',
    description: 'Sofas, designer beds, dining tables, storage wardrobes, home decor, and appliances.',
    subcategories: [
      { id: 'sofa', name: 'Sofa', icon: 'fa-solid fa-couch' },
      { id: 'beds', name: 'Beds', icon: 'fa-solid fa-bed' },
      { id: 'dining-table', name: 'Dining Table', icon: 'fa-solid fa-utensils' },
      { id: 'wardrobes', name: 'Wardrobes', icon: 'fa-solid fa-door-closed' },
      { id: 'home-decor', name: 'Home Decor', icon: 'fa-solid fa-paint-roller' },
      { id: 'appliances', name: 'Appliances', icon: 'fa-solid fa-blender' }
    ]
  },
  {
    id: 'fashion',
    name: 'Fashion & Lifestyle',
    slug: 'fashion',
    icon: 'fa-solid fa-shirt',
    banner: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
    description: 'Men’s & women’s apparel, branded footwear, luxury jewelry, cosmetics, and bags.',
    subcategories: [
      { id: 'mens-fashion', name: "Men's Fashion", icon: 'fa-solid fa-person' },
      { id: 'womens-fashion', name: "Women's Fashion", icon: 'fa-solid fa-person-dress' },
      { id: 'footwear', name: 'Footwear', icon: 'fa-solid fa-shoe-prints' },
      { id: 'jewelry', name: 'Jewelry', icon: 'fa-solid fa-gem' },
      { id: 'cosmetics', name: 'Cosmetics', icon: 'fa-solid fa-wand-magic-sparkles' },
      { id: 'bags-accessories', name: 'Bags & Accessories', icon: 'fa-solid fa-bag-shopping' }
    ]
  },
  {
    id: 'education',
    name: 'Education',
    slug: 'education',
    icon: 'fa-solid fa-book-open',
    banner: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=1200&q=80',
    description: 'Coaching centers, online bootcamps, certified tutors, and skill development programs.',
    subcategories: [
      { id: 'coaching-centers', name: 'Coaching Centers', icon: 'fa-solid fa-school' },
      { id: 'online-courses', name: 'Online Courses', icon: 'fa-solid fa-laptop-code' },
      { id: 'training-institutes', name: 'Training Institutes', icon: 'fa-solid fa-chalkboard-user' },
      { id: 'tutors', name: 'Tutors', icon: 'fa-solid fa-person-chalkboard' },
      { id: 'skill-development', name: 'Skill Development Programs', icon: 'fa-solid fa-certificate' }
    ]
  },
  {
    id: 'services',
    name: 'Services',
    slug: 'services',
    icon: 'fa-solid fa-handshake',
    banner: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1200&q=80',
    description: 'Web development, digital marketing, event management, home repairs, and legal services.',
    subcategories: [
      { id: 'digital-marketing', name: 'Digital Marketing', icon: 'fa-solid fa-bullhorn' },
      { id: 'website-development', name: 'Website Development', icon: 'fa-solid fa-code' },
      { id: 'graphic-design', name: 'Graphic Design', icon: 'fa-solid fa-pen-nib' },
      { id: 'event-management', name: 'Event Management', icon: 'fa-solid fa-champagne-glasses' },
      { id: 'home-services', name: 'Home Services', icon: 'fa-solid fa-screwdriver-wrench' },
      { id: 'legal-services', name: 'Legal Services', icon: 'fa-solid fa-scale-balanced' },
      { id: 'financial-services', name: 'Financial Services', icon: 'fa-solid fa-coins' }
    ]
  },
  {
    id: 'tourism',
    name: 'Tourism & Travel',
    slug: 'tourism',
    icon: 'fa-solid fa-plane',
    banner: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=80',
    description: 'Hotel bookings, holiday tour packages, self-drive car rentals, and luxury stays.',
    subcategories: [
      { id: 'hotel-booking', name: 'Hotel Booking', icon: 'fa-solid fa-hotel' },
      { id: 'tour-packages', name: 'Tour Packages', icon: 'fa-solid fa-map-location-dot' },
      { id: 'car-rentals', name: 'Car Rentals', icon: 'fa-solid fa-car' },
      { id: 'travel-agents', name: 'Travel Agents', icon: 'fa-solid fa-passport' },
      { id: 'holiday-homes', name: 'Holiday Homes', icon: 'fa-solid fa-umbrella-beach' }
    ]
  },
  {
    id: 'business-industrial',
    name: 'Business & Industrial',
    slug: 'business-industrial',
    icon: 'fa-solid fa-industry',
    banner: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=80',
    description: 'Heavy machinery, manufacturing equipment, industrial raw materials, and wholesale items.',
    subcategories: [
      { id: 'machinery', name: 'Machinery', icon: 'fa-solid fa-gears' },
      { id: 'manufacturing-equipment', name: 'Manufacturing Equipment', icon: 'fa-solid fa-boxes-packing' },
      { id: 'construction-equipment', name: 'Construction Equipment', icon: 'fa-solid fa-trowel-bricks' },
      { id: 'industrial-products', name: 'Industrial Products', icon: 'fa-solid fa-cubes' },
      { id: 'wholesale-suppliers', name: 'Wholesale Suppliers', icon: 'fa-solid fa-truck-ramp-box' }
    ]
  },
  {
    id: 'agriculture',
    name: 'Agriculture',
    slug: 'agriculture',
    icon: 'fa-solid fa-wheat-awn',
    banner: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=1200&q=80',
    description: 'Tractors, farming tools, certified seeds, organic fertilizers, livestock, and farm land.',
    subcategories: [
      { id: 'tractors', name: 'Tractors', icon: 'fa-solid fa-tractor' },
      { id: 'farming-equipment', name: 'Farming Equipment', icon: 'fa-solid fa-wheat-awn-circle-exclamation' },
      { id: 'seeds', name: 'Seeds', icon: 'fa-solid fa-seedling' },
      { id: 'fertilizers', name: 'Fertilizers', icon: 'fa-solid fa-flask-vial' },
      { id: 'livestock', name: 'Livestock', icon: 'fa-solid fa-cow' },
      { id: 'agricultural-land', name: 'Agricultural Land', icon: 'fa-solid fa-mountain-sun' }
    ]
  },
  {
    id: 'pets',
    name: 'Pets & Animals',
    slug: 'pets',
    icon: 'fa-solid fa-paw',
    banner: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=1200&q=80',
    description: 'Dogs, puppies, cats, birds, aquariums, pet food, and high-quality accessories.',
    subcategories: [
      { id: 'dogs', name: 'Dogs', icon: 'fa-solid fa-dog' },
      { id: 'cats', name: 'Cats', icon: 'fa-solid fa-cat' },
      { id: 'birds', name: 'Birds', icon: 'fa-solid fa-dove' },
      { id: 'pet-accessories', name: 'Pet Accessories', icon: 'fa-solid fa-bone' }
    ]
  },
  {
    id: 'community',
    name: 'Community',
    slug: 'community',
    icon: 'fa-solid fa-users',
    banner: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=80',
    description: 'Local events, neighborhood volunteering, social groups, donations, and meetups.',
    subcategories: [
      { id: 'events', name: 'Events', icon: 'fa-solid fa-calendar-days' },
      { id: 'local-services', name: 'Local Services', icon: 'fa-solid fa-map-pin' },
      { id: 'donations', name: 'Donations', icon: 'fa-solid fa-hand-holding-heart' },
      { id: 'social-groups', name: 'Social Groups', icon: 'fa-solid fa-people-group' }
    ]
  }
];

// Popular Locations for filtering and posting
const POPULAR_LOCATIONS = [
  'Mumbai, Maharashtra',
  'Delhi NCR, Delhi',
  'Bengaluru, Karnataka',
  'Hyderabad, Telangana',
  'Chennai, Tamil Nadu',
  'Pune, Maharashtra',
  'Kolkata, West Bengal',
  'Ahmedabad, Gujarat',
  'Jaipur, Rajasthan',
  'Chandigarh, Punjab',
  'Goa, North Goa',
  'Kochi, Kerala'
];

// Initial Rich Seed Listings across all 13 Categories
const HOT_DEALS_DATA = [
  {
    id: 'deal-101',
    title: 'Sony PlayStation 5 Disc Edition + 2 DualSense Controllers & God of War Bundle',
    category: 'electronics',
    subcategory: 'accessories',
    originalPrice: 59990,
    price: 38990,
    formattedOriginalPrice: '₹ 59,990',
    formattedPrice: '₹ 38,990',
    discountPercent: 35,
    dealBadge: '35% OFF',
    claimedPercent: 85,
    location: 'Mumbai, Maharashtra',
    locality: 'Bandra West',
    postedDate: '3 hours ago',
    timestamp: Date.now() - 10800000,
    featured: true,
    views: 4320,
    images: [
      'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Special flash deal! Brand new in box Sony PlayStation 5 (Disc Edition - 825GB SSD) bundled with 2 original DualSense wireless controllers, God of War Ragnarök game disc, HDMI 2.1 cable, and 1-year official Sony India warranty.',
    specs: {
      edition: 'Disc Edition',
      storage: '825 GB Ultra-Speed SSD',
      controllers: '2 DualSense Wireless',
      warranty: '1 Year Official Sony Warranty',
      condition: 'Brand New In Box'
    },
    seller: {
      name: 'NexGen Gamers Hub',
      verified: true,
      memberSince: 'Jan 2021',
      phone: '+91 98200 44550',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'deal-102',
    title: '2023 BMW G 310 GS Adventure Tourer (Only 3,200 Km / Showroom Mint)',
    category: 'vehicles',
    subcategory: 'bikes',
    originalPrice: 385000,
    price: 245000,
    formattedOriginalPrice: '₹ 3,85,000',
    formattedPrice: '₹ 2,45,000',
    discountPercent: 36,
    dealBadge: '36% OFF',
    claimedPercent: 70,
    location: 'Bengaluru, Karnataka',
    locality: 'Indiranagar',
    postedDate: '5 hours ago',
    timestamp: Date.now() - 18000000,
    featured: true,
    views: 3180,
    images: [
      'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Urgent relocation deal! Single-owner 2023 BMW G 310 GS in Cosmic Black. Fitted with genuine BMW engine guard, knuckle guards, top box mount, and Pirelli dual-sport tyres. Showroom service record with zero-dep insurance active.',
    specs: {
      brand: 'BMW Motorrad',
      model: 'G 310 GS Adventure',
      year: '2023',
      kmDriven: '3,200 km',
      fuel: 'Petrol',
      transmission: '6-Speed Manual',
      owners: '1st Owner'
    },
    seller: {
      name: 'Karthik Narayanan',
      verified: true,
      memberSince: 'Mar 2020',
      phone: '+91 98450 77889',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'deal-103',
    title: 'Apple MacBook Air M2 13.6" (16GB Unified RAM / 512GB SSD Midnight)',
    category: 'electronics',
    subcategory: 'laptops',
    originalPrice: 119900,
    price: 74500,
    formattedOriginalPrice: '₹ 1,19,900',
    formattedPrice: '₹ 74,500',
    discountPercent: 38,
    dealBadge: '38% OFF',
    claimedPercent: 92,
    location: 'Delhi NCR, Delhi',
    locality: 'Cyber City, Gurugram',
    postedDate: '1 day ago',
    timestamp: Date.now() - 86400000,
    featured: true,
    views: 4890,
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Limited flash sale on custom configuration MacBook Air M2. Upgraded 16GB unified memory, 512GB fast NVMe SSD, Liquid Retina display with True Tone, 1080p FaceTime HD camera. Battery cycle only 18, 100% health with MagSafe 3 charger.',
    specs: {
      brand: 'Apple',
      processor: 'Apple M2 (8-Core CPU / 10-Core GPU)',
      ram: '16 GB Unified Memory',
      storage: '512 GB SSD',
      color: 'Midnight Blue',
      condition: 'Like New / Mint'
    },
    seller: {
      name: 'TechDirect Enterprises',
      verified: true,
      memberSince: 'Jul 2019',
      phone: '+91 98110 33221',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'deal-104',
    title: 'Modern Luxury Emerald Velvet 3-Seater Chesterfield Sofa',
    category: 'home-furniture',
    subcategory: 'sofa',
    originalPrice: 48000,
    price: 26400,
    formattedOriginalPrice: '₹ 48,000',
    formattedPrice: '₹ 26,400',
    discountPercent: 45,
    dealBadge: '45% OFF',
    claimedPercent: 64,
    location: 'Pune, Maharashtra',
    locality: 'Koregaon Park',
    postedDate: 'Yesterday',
    timestamp: Date.now() - 90000000,
    featured: true,
    views: 2150,
    images: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Designer studio clearance sale! Solid neem wood frame with deep button-tufted plush emerald green velvet, brass-tipped conical legs, and pocket-spring high resilience foam cushioning. Includes 2 matching velvet throw cushions.',
    specs: {
      type: '3-Seater Chesterfield',
      material: 'Imported Velvet & Hardwood Frame',
      color: 'Emerald Jewel Green',
      dimensions: '84" W x 35" D x 31" H',
      condition: 'Brand New Clearance'
    },
    seller: {
      name: 'Vogue Living Studios',
      verified: true,
      memberSince: 'Oct 2021',
      phone: '+91 97650 11990',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80'
    }
  }
];

const SEED_LISTINGS = [
  ...HOT_DEALS_DATA,

  // --- REAL ESTATE ---
  {
    id: 're-101',
    title: 'Luxury 3 BHK Sea View Apartment in Bandra West',
    category: 'real-estate',
    subcategory: 'flats-apartments',
    price: 38500000,
    formattedPrice: '₹ 3,85,00,000',
    location: 'Mumbai, Maharashtra',
    locality: 'Bandra West',
    postedDate: '2 days ago',
    timestamp: Date.now() - 172800000,
    featured: true,
    views: 1420,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Immaculate 3 BHK designer home offering panoramic Arabian Sea views. Includes Italian marble flooring, 2 covered parking spots, modular German kitchen, clubhouse access, swimming pool, and round-the-clock gated security.',
    specs: {
      bedrooms: '3 BHK',
      bathrooms: '3',
      area: '1850 sq ft',
      propertyType: 'Apartment',
      furnishing: 'Furnished',
      facing: 'West',
      floor: '18th of 24 Floors',
      ageOfProperty: '1 Year'
    },
    seller: {
      name: 'Oberoi Signature Realty',
      verified: true,
      memberSince: 'Aug 2021',
      phone: '+91 98200 12345',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 're-102',
    title: 'Prime Commercial Corner Office Space in Cyber City',
    category: 'real-estate',
    subcategory: 'office-space',
    price: 18500000,
    formattedPrice: '₹ 1,85,00,000',
    location: 'Delhi NCR, Delhi',
    locality: 'Cyber City, Gurugram',
    postedDate: 'Yesterday',
    timestamp: Date.now() - 86400000,
    featured: false,
    views: 890,
    images: [
      'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Fully furnished, high-yield commercial IT office with 40 workstations, 2 conference rooms, director cabin, server room, cafeteria, and 100% power backup. Ideal for tech startups and corporate firms.',
    specs: {
      area: '2400 sq ft',
      propertyType: 'Office Space',
      furnishing: 'Fully Furnished',
      parking: '4 Dedicated Slots',
      powerBackup: 'Full'
    },
    seller: {
      name: 'Rajesh Varma',
      verified: true,
      memberSince: 'Mar 2022',
      phone: '+91 98110 54321',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 're-103',
    title: 'Gated Villa Plot in Devanahalli Airport Corridor',
    category: 'real-estate',
    subcategory: 'land-plots',
    price: 4500000,
    formattedPrice: '₹ 45,00,000',
    location: 'Bengaluru, Karnataka',
    locality: 'Devanahalli',
    postedDate: '3 days ago',
    timestamp: Date.now() - 259200000,
    featured: false,
    views: 650,
    images: [
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'BIAAPA approved residential villa plot with ready infrastructure: underground drainage, asphalted wide roads, clubhouse, and lush tree-lined walkways. Clear title and bank loan available.',
    specs: {
      area: '1500 sq ft',
      propertyType: 'Residential Plot',
      facing: 'North-East',
      gatedCommunity: 'Yes'
    },
    seller: {
      name: 'Greenfield Developers',
      verified: true,
      memberSince: 'Jan 2023',
      phone: '+91 97400 99887',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- VEHICLES ---
  {
    id: 'veh-201',
    title: '2022 Hyundai Creta SX (O) Turbo Petrol Automatic',
    category: 'vehicles',
    subcategory: 'cars',
    price: 1575000,
    formattedPrice: '₹ 15,75,000',
    location: 'Bengaluru, Karnataka',
    locality: 'Indiranagar',
    postedDate: 'Today',
    timestamp: Date.now() - 3600000,
    featured: true,
    views: 2130,
    images: [
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Single owner, top-end SX (O) DCT turbo petrol with panoramic sunroof, ventilated leather seats, Bose audio, digital cluster, and complete service history at authorized Hyundai service centers. Zero depreciation insurance valid till Dec 2026.',
    specs: {
      brand: 'Hyundai',
      model: 'Creta',
      year: '2022',
      fuel: 'Petrol',
      transmission: 'Automatic (DCT)',
      kmDriven: '24,500 km',
      owners: '1st Owner',
      color: 'Polar White'
    },
    seller: {
      name: 'Aditi Rao',
      verified: true,
      memberSince: 'Jun 2020',
      phone: '+91 98450 11223',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'veh-202',
    title: 'Royal Enfield Continental GT 650 - British Racing Green',
    category: 'vehicles',
    subcategory: 'bikes',
    price: 320000,
    formattedPrice: '₹ 3,20,000',
    location: 'Pune, Maharashtra',
    locality: 'Koregaon Park',
    postedDate: '1 day ago',
    timestamp: Date.now() - 90000000,
    featured: true,
    views: 1100,
    images: [
      'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Mint condition Royal Enfield Continental GT 650. Fitted with original bar-end mirrors, touring dual seat, sump guard, and alloy wheels. Never ridden in heavy traffic; immaculate mechanical and aesthetic condition.',
    specs: {
      brand: 'Royal Enfield',
      model: 'Continental GT 650',
      year: '2023',
      fuel: 'Petrol',
      kmDriven: '6,800 km',
      owners: '1st Owner',
      transmission: 'Manual'
    },
    seller: {
      name: 'Sameer Kulkarni',
      verified: true,
      memberSince: 'Nov 2021',
      phone: '+91 97650 44556',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'veh-203',
    title: 'Tata Nexon EV Max XZ+ Lux 40.5 kWh',
    category: 'vehicles',
    subcategory: 'electric-vehicles',
    price: 1390000,
    formattedPrice: '₹ 13,90,000',
    location: 'Hyderabad, Telangana',
    locality: 'Gachibowli',
    postedDate: '4 days ago',
    timestamp: Date.now() - 345600000,
    featured: false,
    views: 940,
    images: [
      'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'High range EV with 40.5 kWh battery offering real-world ~320 km range. Includes 7.2 kW fast AC home charger, leatherette seats, sunroof, and 8-year Tata battery warranty intact.',
    specs: {
      brand: 'Tata',
      model: 'Nexon EV Max',
      year: '2023',
      fuel: 'Electric',
      transmission: 'Automatic',
      kmDriven: '18,200 km',
      owners: '1st Owner'
    },
    seller: {
      name: 'Venkatesh Rao',
      verified: true,
      memberSince: 'Feb 2023',
      phone: '+91 99890 33221',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- ELECTRONICS ---
  {
    id: 'elec-301',
    title: 'Apple iPhone 15 Pro Max 256GB Natural Titanium (Under AppleCare+)',
    category: 'electronics',
    subcategory: 'mobile-phones',
    price: 98000,
    formattedPrice: '₹ 98,000',
    location: 'Mumbai, Maharashtra',
    locality: 'Andheri West',
    postedDate: '3 hours ago',
    timestamp: Date.now() - 10800000,
    featured: true,
    views: 3200,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1000&q=80'
    ],
    description: '100% battery health, completely scratchless condition with tempered glass and Spigen cover. Comes with original box, braided USB-C cable, bill, and AppleCare+ warranty valid until late 2026.',
    specs: {
      brand: 'Apple',
      model: 'iPhone 15 Pro Max',
      storage: '256 GB',
      ram: '8 GB',
      condition: 'Like New / Mint',
      color: 'Natural Titanium',
      warranty: '6 Months AppleCare+ Left'
    },
    seller: {
      name: 'Karan Mehra',
      verified: true,
      memberSince: 'Oct 2020',
      phone: '+91 99200 45678',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'elec-302',
    title: 'MacBook Pro 16" M3 Max (36GB Unified Memory / 1TB SSD)',
    category: 'electronics',
    subcategory: 'laptops',
    price: 245000,
    formattedPrice: '₹ 2,45,000',
    location: 'Bengaluru, Karnataka',
    locality: 'Koramangala',
    postedDate: '5 hours ago',
    timestamp: Date.now() - 18000000,
    featured: true,
    views: 1800,
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Space Black M3 Max monster workhorse. 14-core CPU, 30-core GPU, Liquid Retina XDR screen with 120Hz ProMotion. Battery cycle count only 24. Selling due to company laptop upgrade.',
    specs: {
      brand: 'Apple',
      model: 'MacBook Pro 16',
      ram: '36 GB',
      storage: '1 TB SSD',
      condition: 'Like New',
      processor: 'Apple M3 Max'
    },
    seller: {
      name: 'Rohan Sharma',
      verified: true,
      memberSince: 'May 2019',
      phone: '+91 98800 77112',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'elec-303',
    title: 'Sony Alpha 7 IV Full-Frame Mirrorless Camera + 24-70mm GM Lens',
    category: 'electronics',
    subcategory: 'cameras',
    price: 195000,
    formattedPrice: '₹ 1,95,00,0',
    location: 'Delhi NCR, Delhi',
    locality: 'South Extension',
    postedDate: '2 days ago',
    timestamp: Date.now() - 172800000,
    featured: false,
    views: 740,
    images: [
      'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1000&q=80'
    ],
    description: '33MP BSI CMOS sensor, 4K 60p 10-bit recording, shutter count less than 4,200 shots. Includes 2 extra genuine NP-FZ100 batteries, dual charger, and Sandisk Extreme Pro 128GB V90 card.',
    specs: {
      brand: 'Sony',
      model: 'A7 IV',
      condition: 'Excellent',
      lensIncluded: 'Yes (Sony FE 24-70mm f/2.8 GM)',
      shutterCount: '4,150'
    },
    seller: {
      name: 'Pooja Bedi',
      verified: true,
      memberSince: 'Sep 2022',
      phone: '+91 98180 33445',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- JOBS ---
  {
    id: 'job-401',
    title: 'Senior Full Stack React & Node.js Engineer (Remote)',
    category: 'jobs',
    subcategory: 'work-from-home',
    price: 2400000,
    formattedPrice: '₹ 20,00,000 - ₹ 28,00,000 / yr',
    location: 'Bengaluru, Karnataka',
    locality: 'Remote (Anywhere in India)',
    postedDate: '1 day ago',
    timestamp: Date.now() - 86400000,
    featured: true,
    views: 2900,
    images: [
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'US-based fintech product firm seeking experienced Full Stack developer with strong skills in TypeScript, Next.js, GraphQL, PostgreSQL, and AWS. Generous equity + health insurance + home office stipend included.',
    specs: {
      jobType: 'Full-Time',
      workMode: 'Remote / Work From Home',
      experience: '4 - 7 Years',
      salaryRange: '₹ 20 - 28 LPA',
      education: 'B.Tech / B.E / MCA',
      company: 'FinPulse Technologies'
    },
    seller: {
      name: 'Talent Acquisition Team',
      verified: true,
      memberSince: 'Jan 2021',
      phone: '+91 80400 55660',
      avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'job-402',
    title: 'Senior Digital Marketing & Growth Lead',
    category: 'jobs',
    subcategory: 'full-time-jobs',
    price: 1200000,
    formattedPrice: '₹ 10,00,000 - ₹ 14,00,000 / yr',
    location: 'Mumbai, Maharashtra',
    locality: 'BKC, Mumbai',
    postedDate: '3 days ago',
    timestamp: Date.now() - 259200000,
    featured: false,
    views: 1200,
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Lead omnichannel performance marketing, Meta Ads, Google PPC campaigns, and conversion rate optimization for a fast-scaling D2C brand.',
    specs: {
      jobType: 'Full-Time',
      workMode: 'Hybrid (3 days office)',
      experience: '3 - 5 Years',
      salaryRange: '₹ 10 - 14 LPA',
      company: 'Velocita Brands'
    },
    seller: {
      name: 'HR Velocita',
      verified: true,
      memberSince: 'Aug 2023',
      phone: '+91 98210 99001',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- HOME & FURNITURE ---
  {
    id: 'hf-501',
    title: 'Solid Teak Wood L-Shape 6-Seater Sectional Sofa',
    category: 'home-furniture',
    subcategory: 'sofa',
    price: 38500,
    formattedPrice: '₹ 38,500',
    location: 'Pune, Maharashtra',
    locality: 'Baner',
    postedDate: 'Yesterday',
    timestamp: Date.now() - 86400000,
    featured: true,
    views: 890,
    images: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Custom handcrafted genuine Burma teak sectional sofa with premium stain-resistant beige upholstery and high-density 40D Sleepwell foam cushioning. Barely 8 months old.',
    specs: {
      type: 'L-Shape Sectional',
      seatingCapacity: '6 Seater',
      material: 'Solid Teak Wood',
      color: 'Warm Beige / Walnut Frame',
      condition: 'Excellent'
    },
    seller: {
      name: 'Sanjay Deshmukh',
      verified: true,
      memberSince: 'Jul 2022',
      phone: '+91 98900 12890',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'hf-502',
    title: 'King Size Hydraulic Storage Bed with Orthopedic Mattress',
    category: 'home-furniture',
    subcategory: 'beds',
    price: 24000,
    formattedPrice: '₹ 24,000',
    location: 'Delhi NCR, Delhi',
    locality: 'Dwarka',
    postedDate: '4 days ago',
    timestamp: Date.now() - 345600000,
    featured: false,
    views: 620,
    images: [
      'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Engineered wood king size bed (72x78 inches) with easy gas-lift hydraulic storage and headboard cushions. Wakefit 8-inch memory foam orthopedic mattress included.',
    specs: {
      bedSize: 'King Size (72x78)',
      storageType: 'Hydraulic Storage',
      material: 'High-Density Engineered Wood',
      condition: 'Very Good'
    },
    seller: {
      name: 'Vikram Sethi',
      verified: false,
      memberSince: 'Nov 2023',
      phone: '+91 98710 44332',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- FASHION & LIFESTYLE ---
  {
    id: 'fash-601',
    title: 'Seiko Presage Cocktail Time Automatic Watch (SRPB43J1)',
    category: 'fashion',
    subcategory: 'bags-accessories',
    price: 32500,
    formattedPrice: '₹ 32,500',
    location: 'Mumbai, Maharashtra',
    locality: 'Colaba',
    postedDate: 'Today',
    timestamp: Date.now() - 7200000,
    featured: true,
    views: 1450,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Stunning sunburst ice-blue dial with 4R35 automatic movement, exhibition caseback, and original black calfskin strap with deployant buckle. Complete with warranty card & wooden presentation box.',
    specs: {
      brand: 'Seiko',
      movement: 'Automatic (41hr reserve)',
      caseDiameter: '40.5mm',
      condition: 'Unworn / Brand New in Box',
      gender: 'Men / Unisex'
    },
    seller: {
      name: 'Arjun Kapoor',
      verified: true,
      memberSince: 'Mar 2021',
      phone: '+91 98200 90123',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- EDUCATION ---
  {
    id: 'edu-701',
    title: 'Full Stack Web Development & AI Masterclass (1-on-1 Mentorship)',
    category: 'education',
    subcategory: 'online-courses',
    price: 15000,
    formattedPrice: '₹ 15,000 / Batch',
    location: 'Hyderabad, Telangana',
    locality: 'Online Live Sessions',
    postedDate: '2 days ago',
    timestamp: Date.now() - 172800000,
    featured: true,
    views: 820,
    images: [
      'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Hands-on practical training covering HTML5, CSS3, Modern JS, React, Node.js, and GenAI integrations with 10 live project builds and placement guidance.',
    specs: {
      mode: 'Online Live Interactive',
      duration: '12 Weeks',
      batchSize: 'Limited to 15 Students',
      certification: 'Included'
    },
    seller: {
      name: 'CodeCraft Academy',
      verified: true,
      memberSince: 'Feb 2022',
      phone: '+91 99490 88776',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- SERVICES ---
  {
    id: 'serv-801',
    title: 'Professional SEO, Google Ads & Social Media Growth Agency',
    category: 'services',
    subcategory: 'digital-marketing',
    price: 25000,
    formattedPrice: '₹ 25,000 / mo',
    location: 'Delhi NCR, Delhi',
    locality: 'Connaught Place',
    postedDate: '5 days ago',
    timestamp: Date.now() - 432000000,
    featured: false,
    views: 510,
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Grow your ecommerce sales and business leads with proven technical SEO, Google Search campaigns, and Instagram/Meta advertising with monthly ROI reporting.',
    specs: {
      serviceType: 'Monthly Retainer',
      deliverables: 'SEO Audit + Paid Ads + Content',
      experience: '8+ Years'
    },
    seller: {
      name: 'Apex Growth Media',
      verified: true,
      memberSince: 'May 2021',
      phone: '+91 98100 66778',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- TOURISM & TRAVEL ---
  {
    id: 'tour-901',
    title: 'Luxury 4-Bedroom Private Pool Villa in Candolim, North Goa',
    category: 'tourism',
    subcategory: 'holiday-homes',
    price: 18000,
    formattedPrice: '₹ 18,000 / Night',
    location: 'Goa, North Goa',
    locality: 'Candolim',
    postedDate: 'Yesterday',
    timestamp: Date.now() - 86400000,
    featured: true,
    views: 2400,
    images: [
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Portuguese heritage architectural villa with private infinity pool, cook-on-demand service, air conditioning in all rooms, high-speed WiFi, and walking distance to Candolim beach.',
    specs: {
      bedrooms: '4 Bedrooms (Sleeps 10)',
      amenities: 'Private Pool, Butler, WiFi, Lawn',
      distanceToBeach: '400 meters'
    },
    seller: {
      name: 'Goa Holiday Stays',
      verified: true,
      memberSince: 'Dec 2020',
      phone: '+91 83200 44556',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- BUSINESS & INDUSTRIAL ---
  {
    id: 'biz-1001',
    title: 'Industrial 3-Phase CNC Laser Cutting Machine (1500W Fiber)',
    category: 'business-industrial',
    subcategory: 'machinery',
    price: 950000,
    formattedPrice: '₹ 9,50,000',
    location: 'Ahmedabad, Gujarat',
    locality: 'GIDC Industrial Estate',
    postedDate: '3 days ago',
    timestamp: Date.now() - 259200000,
    featured: false,
    views: 480,
    images: [
      'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Raycus 1500W fiber laser source capable of slicing up to 14mm carbon steel and 6mm stainless steel. Heavy gantry construction with Cypcut controller. On-site installation included.',
    specs: {
      laserPower: '1500W Fiber',
      workingArea: '3000 x 1500 mm',
      condition: 'Brand New',
      powerSupply: '415V 50Hz 3-Phase'
    },
    seller: {
      name: 'Precision Laser Tech',
      verified: true,
      memberSince: 'Jun 2022',
      phone: '+91 97200 88112',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- AGRICULTURE ---
  {
    id: 'agri-1101',
    title: 'Mahindra 575 DI Sarpanch Tractor (45 HP / Power Steering)',
    category: 'agriculture',
    subcategory: 'tractors',
    price: 420000,
    formattedPrice: '₹ 4,20,000',
    location: 'Jaipur, Rajasthan',
    locality: 'Chomu',
    postedDate: '4 days ago',
    timestamp: Date.now() - 345600000,
    featured: true,
    views: 1120,
    images: [
      'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Well-maintained 45 HP workhorse with new Apollo rear tyres, dual clutch, power steering, oil immersed brakes, and cultivator attachment.',
    specs: {
      brand: 'Mahindra',
      model: '575 DI Sarpanch',
      hp: '45 HP',
      year: '2021',
      hoursRun: '1,450 Hrs',
      condition: 'Excellent'
    },
    seller: {
      name: 'Ramsingh Choudhary',
      verified: true,
      memberSince: 'Apr 2021',
      phone: '+91 94140 77665',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- PETS & ANIMALS ---
  {
    id: 'pet-1201',
    title: 'Golden Retriever Puppies (KCI Certified / Vaccinated & Dewormed)',
    category: 'pets',
    subcategory: 'dogs',
    price: 22000,
    formattedPrice: '₹ 22,000',
    location: 'Chandigarh, Punjab',
    locality: 'Sector 34',
    postedDate: '1 day ago',
    timestamp: Date.now() - 86400000,
    featured: true,
    views: 1980,
    images: [
      'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Adorable, champion bloodline Golden Retriever puppies (male and female available). Microchipped, KCI registered, fully dewormed, and first 7-in-1 vaccination completed.',
    specs: {
      breed: 'Golden Retriever',
      age: '55 Days',
      gender: 'Male & Female',
      vaccinated: 'Yes',
      kciCertified: 'Yes'
    },
    seller: {
      name: 'Harmit Singh',
      verified: true,
      memberSince: 'Nov 2021',
      phone: '+91 98760 11229',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    }
  },

  // --- COMMUNITY ---
  {
    id: 'comm-1301',
    title: 'Weekend Blood Donation & Free Health Checkup Camp',
    category: 'community',
    subcategory: 'events',
    price: 0,
    formattedPrice: 'Free / Volunteer',
    location: 'Kochi, Kerala',
    locality: 'Marine Drive Grounds',
    postedDate: 'Today',
    timestamp: Date.now() - 14400000,
    featured: false,
    views: 430,
    images: [
      'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1000&q=80'
    ],
    description: 'Join us this Sunday from 9:00 AM to 4:00 PM for the annual city community blood donation drive. Refreshments, donor certificates, and basic wellness checkups provided for all volunteers.',
    specs: {
      eventType: 'Community Health Drive',
      entryFee: 'Free',
      date: 'This Upcoming Sunday',
      organizer: 'Red Cross Youth Volunteers'
    },
    seller: {
      name: 'Kerala Youth Club',
      verified: true,
      memberSince: 'Jan 2022',
      phone: '+91 94470 12340',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    }
  }
];

// Helper Data Manager
const DataStore = {
  // Initialize LocalStorage with seed listings if empty or merge new seed items
  init() {
    const existingRaw = localStorage.getItem(STORAGE_KEYS.LISTINGS);
    if (!existingRaw) {
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(SEED_LISTINGS));
    } else {
      try {
        const parsed = JSON.parse(existingRaw);
        let updated = false;
        SEED_LISTINGS.forEach(seedItem => {
          const idx = parsed.findIndex(p => p.id === seedItem.id);
          if (idx === -1) {
            parsed.push(seedItem);
            updated = true;
          } else {
            // Update images and formatted fields for seed listings
            if (JSON.stringify(parsed[idx].images) !== JSON.stringify(seedItem.images) || parsed[idx].discountPercent !== seedItem.discountPercent) {
              parsed[idx].images = seedItem.images;
              parsed[idx].price = seedItem.price;
              parsed[idx].formattedPrice = seedItem.formattedPrice;
              if (seedItem.originalPrice) {
                parsed[idx].originalPrice = seedItem.originalPrice;
                parsed[idx].formattedOriginalPrice = seedItem.formattedOriginalPrice;
                parsed[idx].discountPercent = seedItem.discountPercent;
                parsed[idx].dealBadge = seedItem.dealBadge;
                parsed[idx].claimedPercent = seedItem.claimedPercent;
              }
              updated = true;
            }
          }
        });
        if (updated) {
          localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(parsed));
        }
      } catch (e) {
        localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(SEED_LISTINGS));
      }
    }
    if (!localStorage.getItem(STORAGE_KEYS.WISHLIST)) {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(['veh-201', 'elec-301']));
    }
    if (!localStorage.getItem(STORAGE_KEYS.RECENT_SEARCHES)) {
      localStorage.setItem(STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(['iPhone 15', 'Hyundai Creta', 'Bandra 3 BHK']));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
      // Default demo logged-in user
      const defaultUser = {
        id: 'usr-901',
        name: 'Aditya Sharma',
        email: 'aditya@example.com',
        phone: '+91 98200 88990',
        memberSince: 'March 2023',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
        location: 'Mumbai, Maharashtra',
        verified: true
      };
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(defaultUser));
    }
  },

  getListings() {
    this.init();
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.LISTINGS)) || SEED_LISTINGS;
    } catch (e) {
      console.error('Error reading listings from localStorage:', e);
      return SEED_LISTINGS;
    }
  },

  getHotDeals() {
    return HOT_DEALS_DATA;
  },

  getListingById(id) {
    const listings = this.getListings();
    return listings.find(item => item.id === id) || null;
  },

  saveListing(listingData) {
    const listings = this.getListings();
    // Add unique ID, timestamps, formatting if not present
    const id = listingData.id || 'usr-ad-' + Date.now();
    const formattedPrice = listingData.price > 0 
      ? '₹ ' + Number(listingData.price).toLocaleString('en-IN') 
      : 'Free / Contact';
      
    const newListing = {
      ...listingData,
      id,
      formattedPrice,
      postedDate: 'Just now',
      timestamp: Date.now(),
      views: 1
    };

    listings.unshift(newListing);
    localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(listings));
    return newListing;
  },

  deleteListing(id) {
    let listings = this.getListings();
    listings = listings.filter(item => item.id !== id);
    localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(listings));
    return listings;
  },

  getCategories() {
    return CATEGORIES_DATA;
  },

  getCategoryBySlug(slug) {
    return CATEGORIES_DATA.find(c => c.slug === slug || c.id === slug) || null;
  },

  getLocations() {
    return POPULAR_LOCATIONS;
  },

  getWishlist() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.WISHLIST)) || [];
    } catch (e) {
      return [];
    }
  },

  toggleWishlist(listingId) {
    let wishlist = this.getWishlist();
    const index = wishlist.indexOf(listingId);
    let isAdded = false;

    if (index > -1) {
      wishlist.splice(index, 1);
      isAdded = false;
    } else {
      wishlist.push(listingId);
      isAdded = true;
    }

    localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
    // Dispatch custom event for UI updates
    window.dispatchEvent(new CustomEvent('wishlistUpdated', { detail: { wishlist, listingId, isAdded } }));
    return isAdded;
  },

  isWishlisted(listingId) {
    return this.getWishlist().includes(listingId);
  },

  getCurrentUser() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) || null;
    } catch (e) {
      return null;
    }
  },

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
    window.dispatchEvent(new CustomEvent('authStateChanged', { detail: { user } }));
  },

  getRecentSearches() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.RECENT_SEARCHES)) || [];
    } catch (e) {
      return [];
    }
  },

  addRecentSearch(term) {
    if (!term || term.trim().length === 0) return;
    let searches = this.getRecentSearches();
    searches = searches.filter(s => s.toLowerCase() !== term.toLowerCase().trim());
    searches.unshift(term.trim());
    searches = searches.slice(0, 8); // Keep top 8
    localStorage.setItem(STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(searches));
  }
};

// Run initialization immediately
DataStore.init();

// Export globally for browser scripts
window.DataStore = DataStore;
window.HOT_DEALS_DATA = HOT_DEALS_DATA;
window.CATEGORIES_DATA = CATEGORIES_DATA;
window.POPULAR_LOCATIONS = POPULAR_LOCATIONS;
