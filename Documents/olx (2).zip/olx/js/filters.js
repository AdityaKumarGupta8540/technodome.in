/**
 * OLX Dynamic Filtering & Sorting Engine
 * Handles multi-filter combinations, category-specific facets, and real-time listing results.
 */

const Filters = {
  currentCategory: null,
  currentSubcategory: null,
  activeFilters: {},

  init(categorySlug = null) {
    this.currentCategory = categorySlug;
    this.bindFilterEvents();
    this.renderCategorySpecificFilters();
    this.applyFilters();
  },

  renderCategorySpecificFilters() {
    const container = document.getElementById('category-specific-filters');
    if (!container) return;

    if (!this.currentCategory) {
      container.innerHTML = '';
      return;
    }

    let html = '';

    // Real Estate Custom Filters
    if (this.currentCategory === 'real-estate') {
      html += `
        <div class="filter-group">
          <div class="filter-title">Bedrooms</div>
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.35rem;">
            <button class="btn btn-sm btn-secondary filter-chip" data-spec-key="bedrooms" data-spec-val="1 BHK">1 BHK</button>
            <button class="btn btn-sm btn-secondary filter-chip" data-spec-key="bedrooms" data-spec-val="2 BHK">2 BHK</button>
            <button class="btn btn-sm btn-secondary filter-chip" data-spec-key="bedrooms" data-spec-val="3 BHK">3 BHK</button>
          </div>
        </div>
        <div class="filter-group">
          <div class="filter-title">Furnishing</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_furnishing" value="Furnished"> Furnished</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_furnishing" value="Semi-Furnished"> Semi-Furnished</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_furnishing" value="Unfurnished"> Unfurnished</label>
        </div>
      `;
    } 
    // Vehicles Custom Filters
    else if (this.currentCategory === 'vehicles') {
      html += `
        <div class="filter-group">
          <div class="filter-title">Fuel Type</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_fuel" value="Petrol"> Petrol</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_fuel" value="Diesel"> Diesel</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_fuel" value="Electric"> Electric / EV</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_fuel" value="CNG"> CNG</label>
        </div>
        <div class="filter-group">
          <div class="filter-title">Transmission</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_transmission" value="Automatic"> Automatic</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_transmission" value="Manual"> Manual</label>
        </div>
      `;
    }
    // Electronics Custom Filters
    else if (this.currentCategory === 'electronics') {
      html += `
        <div class="filter-group">
          <div class="filter-title">Brand</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_brand" value="Apple"> Apple</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_brand" value="Samsung"> Samsung</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_brand" value="Sony"> Sony</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_brand" value="Dell"> Dell / HP</label>
        </div>
        <div class="filter-group">
          <div class="filter-title">Condition</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_condition" value="Like New"> Like New / Mint</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_condition" value="Good"> Good / Working</label>
        </div>
      `;
    }
    // Jobs Custom Filters
    else if (this.currentCategory === 'jobs') {
      html += `
        <div class="filter-group">
          <div class="filter-title">Job Type</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_jobType" value="Full-Time"> Full-Time</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_jobType" value="Part-Time"> Part-Time</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_jobType" value="Internship"> Internship</label>
        </div>
        <div class="filter-group">
          <div class="filter-title">Work Mode</div>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_workMode" value="Remote"> Remote / WFH</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_workMode" value="Hybrid"> Hybrid</label>
          <label class="filter-checkbox-label"><input type="checkbox" name="spec_workMode" value="On-Site"> On-Site Office</label>
        </div>
      `;
    }

    container.innerHTML = html;

    // Bind chip buttons and checkbox events
    container.querySelectorAll('.filter-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.classList.toggle('active');
        if (btn.classList.contains('active')) {
          btn.style.background = 'var(--color-primary)';
          btn.style.color = '#fff';
        } else {
          btn.style.background = 'var(--bg-surface)';
          btn.style.color = 'var(--color-primary)';
        }
        this.applyFilters();
      });
    });

    container.querySelectorAll('input[type="checkbox"]').forEach(chk => {
      chk.addEventListener('change', () => this.applyFilters());
    });
  },

  bindFilterEvents() {
    const minPriceInput = document.getElementById('filter-min-price');
    const maxPriceInput = document.getElementById('filter-max-price');
    const sortSelect = document.getElementById('filter-sort-select');
    const resetBtn = document.getElementById('btn-reset-filters');
    const applyPriceBtn = document.getElementById('btn-apply-price');

    if (minPriceInput) minPriceInput.addEventListener('change', () => this.applyFilters());
    if (maxPriceInput) maxPriceInput.addEventListener('change', () => this.applyFilters());
    if (applyPriceBtn) applyPriceBtn.addEventListener('click', () => this.applyFilters());
    if (sortSelect) sortSelect.addEventListener('change', () => this.applyFilters());

    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this.resetFilters();
      });
    }

    // Subcategory pill clicks
    document.querySelectorAll('.subcat-pill').forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.preventDefault();
        const subcatId = pill.getAttribute('data-subcat');
        document.querySelectorAll('.subcat-pill').forEach(p => p.classList.remove('active'));

        if (this.currentSubcategory === subcatId) {
          this.currentSubcategory = null;
        } else {
          pill.classList.add('active');
          this.currentSubcategory = subcatId;
        }
        this.applyFilters();
      });
    });
  },

  resetFilters() {
    const minPrice = document.getElementById('filter-min-price');
    const maxPrice = document.getElementById('filter-max-price');
    const sortSelect = document.getElementById('filter-sort-select');

    if (minPrice) minPrice.value = '';
    if (maxPrice) maxPrice.value = '';
    if (sortSelect) sortSelect.value = 'newest';

    document.querySelectorAll('#category-specific-filters input[type="checkbox"]').forEach(chk => {
      chk.checked = false;
    });

    document.querySelectorAll('.filter-chip').forEach(btn => {
      btn.classList.remove('active');
      btn.style.background = 'var(--bg-surface)';
      btn.style.color = 'var(--color-primary)';
    });

    document.querySelectorAll('.subcat-pill').forEach(p => p.classList.remove('active'));
    this.currentSubcategory = null;

    this.applyFilters();
  },

  applyFilters() {
    const listings = window.DataStore.getListings();
    const searchInput = document.getElementById('global-search-input');
    const searchTerm = (searchInput ? searchInput.value : '').toLowerCase().trim();
    const location = window.Search ? window.Search.selectedLocation : 'All India';

    const minPriceEl = document.getElementById('filter-min-price');
    const maxPriceEl = document.getElementById('filter-max-price');
    const minPrice = minPriceEl && minPriceEl.value ? parseFloat(minPriceEl.value) : 0;
    const maxPrice = maxPriceEl && maxPriceEl.value ? parseFloat(maxPriceEl.value) : Infinity;

    const sortSelect = document.getElementById('filter-sort-select');
    const sortMode = sortSelect ? sortSelect.value : 'newest';

    // Gather specific filters
    const selectedCheckboxes = {};
    document.querySelectorAll('#category-specific-filters input[type="checkbox"]:checked').forEach(chk => {
      const name = chk.name;
      if (!selectedCheckboxes[name]) selectedCheckboxes[name] = [];
      selectedCheckboxes[name].push(chk.value.toLowerCase());
    });

    const activeChips = [];
    document.querySelectorAll('.filter-chip.active').forEach(chip => {
      activeChips.push({
        key: chip.getAttribute('data-spec-key'),
        val: chip.getAttribute('data-spec-val').toLowerCase()
      });
    });

    // Filter listings
    let filtered = listings.filter(item => {
      // 1. Category Filter
      if (this.currentCategory && item.category !== this.currentCategory) {
        return false;
      }

      // 2. Subcategory Filter
      if (this.currentSubcategory && item.subcategory !== this.currentSubcategory) {
        return false;
      }

      // 3. Search Query Filter
      if (searchTerm) {
        const matchesTitle = item.title.toLowerCase().includes(searchTerm);
        const matchesDesc = (item.description || '').toLowerCase().includes(searchTerm);
        const matchesLoc = (item.location || '').toLowerCase().includes(searchTerm);
        const matchesCat = (item.category || '').toLowerCase().includes(searchTerm);
        if (!matchesTitle && !matchesDesc && !matchesLoc && !matchesCat) {
          return false;
        }
      }

      // 4. Location Filter
      if (location && location !== 'All India') {
        const locClean = location.split(',')[0].toLowerCase().trim();
        if (!item.location.toLowerCase().includes(locClean)) {
          return false;
        }
      }

      // 5. Price Filter
      if (item.price < minPrice || item.price > maxPrice) {
        return false;
      }

      // 6. Category Specific Attributes
      if (item.specs) {
        // Checkboxes
        for (const [key, values] of Object.entries(selectedCheckboxes)) {
          const specField = key.replace('spec_', '');
          const itemVal = (item.specs[specField] || '').toLowerCase();
          const matchesAny = values.some(v => itemVal.includes(v));
          if (!matchesAny) return false;
        }

        // Active Chips
        for (const chip of activeChips) {
          const itemVal = (item.specs[chip.key] || '').toLowerCase();
          if (!itemVal.includes(chip.val)) return false;
        }
      }

      return true;
    });

    // Sort listings
    if (sortMode === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortMode === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortMode === 'popular') {
      filtered.sort((a, b) => (b.views || 0) - (a.views || 0));
    } else {
      // Newest (default)
      filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    }

    // Render Results
    this.renderResults(filtered);
  },

  renderResults(results) {
    const grid = document.getElementById('listings-results-grid');
    const countEl = document.getElementById('results-count-display');

    if (countEl) {
      countEl.textContent = `${results.length} Ad${results.length === 1 ? '' : 's'} Found`;
    }

    if (!grid) return;

    if (results.length === 0) {
      grid.innerHTML = `
        <div class="empty-state text-center" style="grid-column: 1 / -1; padding: 3rem 1rem; background: var(--bg-surface); border-radius: var(--border-radius-md); border: 1px solid var(--border-color-light);">
          <div style="font-size: 3.5rem; color: var(--text-muted); margin-bottom: 0.75rem;">
            <i class="fa-solid fa-magnifying-glass-chart"></i>
          </div>
          <h3 style="margin-bottom: 0.5rem;">No Listings Found</h3>
          <p style="margin-bottom: 1.5rem;">We couldn't find any ads matching your selected filters or keywords.</p>
          <button id="empty-reset-btn" class="btn btn-primary">Clear All Filters</button>
        </div>
      `;
      const emptyReset = document.getElementById('empty-reset-btn');
      if (emptyReset) emptyReset.addEventListener('click', () => this.resetFilters());
      return;
    }

    let html = '';
    results.forEach(item => {
      html += window.Listings.createCardHtml(item);
    });
    grid.innerHTML = html;
  }
};

window.Filters = Filters;
