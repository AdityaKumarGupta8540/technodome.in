/**
 * OLX Modal & Popups Controller
 * Manages reusable modals: Auth, Contact Seller, Live Chat, Share, Report, Lightbox Zoom.
 */

const Modal = {
  init() {
    this.injectModals();
    this.bindEvents();
  },

  injectModals() {
    if (document.getElementById('global-modals-container')) return;

    const modalContainer = document.createElement('div');
    modalContainer.id = 'global-modals-container';
    modalContainer.innerHTML = `
      <!-- 1. AUTH MODAL (Login / Register) -->
      <div id="modal-auth" class="modal-backdrop">
        <div class="modal-dialog">
          <div class="modal-header">
            <h3 id="auth-modal-title">Sign In to OLX</h3>
            <button class="modal-close-btn" data-close-modal>&times;</button>
          </div>
          <div class="modal-body">
            <!-- Tabs -->
            <div style="display: flex; border-bottom: 2px solid var(--border-color-light); margin-bottom: 1.25rem;">
              <button id="tab-login-btn" class="btn" style="flex: 1; border-radius: 0; border-bottom: 3px solid var(--color-primary); font-weight: 700;">Login</button>
              <button id="tab-register-btn" class="btn" style="flex: 1; border-radius: 0; color: var(--text-muted); font-weight: 700;">Register</button>
            </div>

            <!-- Login Form -->
            <form id="form-login">
              <div style="margin-bottom: 1rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Email / Phone</label>
                <input type="text" id="login-email" class="filter-input" placeholder="e.g. aditya@example.com" value="aditya@example.com" required style="width: 100%; padding: 0.75rem;">
              </div>
              <div style="margin-bottom: 1.25rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Password</label>
                <input type="password" id="login-password" class="filter-input" placeholder="••••••••" value="demo1234" required style="width: 100%; padding: 0.75rem;">
              </div>
              <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-bottom: 0.75rem;">Log In</button>
              <div class="text-center">
                <a href="#" id="link-forgot-password" style="font-size: 0.85rem; color: var(--color-primary); font-weight: 600;">Forgot Password?</a>
              </div>
            </form>

            <!-- Register Form -->
            <form id="form-register" style="display: none;">
              <div style="margin-bottom: 1rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Full Name</label>
                <input type="text" id="reg-name" class="filter-input" placeholder="John Doe" required style="width: 100%; padding: 0.75rem;">
              </div>
              <div style="margin-bottom: 1rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Email Address</label>
                <input type="email" id="reg-email" class="filter-input" placeholder="name@domain.com" required style="width: 100%; padding: 0.75rem;">
              </div>
              <div style="margin-bottom: 1rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Phone Number</label>
                <input type="tel" id="reg-phone" class="filter-input" placeholder="+91 98000 00000" style="width: 100%; padding: 0.75rem;">
              </div>
              <div style="margin-bottom: 1.25rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Create Password</label>
                <input type="password" id="reg-password" class="filter-input" placeholder="••••••••" required style="width: 100%; padding: 0.75rem;">
              </div>
              <button type="submit" class="btn btn-primary btn-block btn-lg">Create Account</button>
            </form>
          </div>
        </div>
      </div>

      <!-- 2. CONTACT SELLER MODAL -->
      <div id="modal-contact-seller" class="modal-backdrop">
        <div class="modal-dialog">
          <div class="modal-header">
            <h3>Contact Seller</h3>
            <button class="modal-close-btn" data-close-modal>&times;</button>
          </div>
          <div class="modal-body text-center" id="contact-seller-body">
            <div style="font-size: 3rem; color: var(--color-primary); margin-bottom: 0.5rem;">
              <i class="fa-solid fa-phone-volume"></i>
            </div>
            <h4 id="contact-seller-name" style="margin-bottom: 0.25rem;">Seller Name</h4>
            <p id="contact-seller-verified" style="color: var(--color-success); font-weight: 600; font-size: 0.85rem; margin-bottom: 1.25rem;">
              <i class="fa-solid fa-circle-check"></i> Verified OLX Seller
            </p>
            
            <div style="background: var(--bg-subtle); padding: 1rem; border-radius: var(--border-radius-sm); margin-bottom: 1.5rem;">
              <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase;">Direct Mobile Number</div>
              <div id="contact-seller-phone" style="font-size: 1.5rem; font-weight: 800; color: var(--color-primary); margin-top: 0.25rem;">+91 98200 00000</div>
            </div>

            <div style="display: flex; gap: 0.75rem;">
              <a id="btn-call-seller" href="#" class="btn btn-primary" style="flex: 1;">
                <i class="fa-solid fa-phone"></i> Call Now
              </a>
              <a id="btn-whatsapp-seller" href="#" target="_blank" class="btn" style="flex: 1; background: #25d366; color: #fff;">
                <i class="fa-brands fa-whatsapp"></i> WhatsApp
              </a>
            </div>

            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 1.25rem;">
              <i class="fa-solid fa-shield-halved"></i> Safety Tip: Avoid paying in advance. Meet the seller in a safe, public place.
            </p>
          </div>
        </div>
      </div>

      <!-- 3. LIVE CHAT MODAL -->
      <div id="modal-chat" class="modal-backdrop">
        <div class="modal-dialog modal-lg">
          <div class="modal-header" style="background: var(--color-primary); color: #fff;">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <img id="chat-seller-avatar" src="" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;" alt="Seller">
              <div>
                <h4 id="chat-seller-name" style="color: #fff; font-size: 1rem;">Chat</h4>
                <div style="font-size: 0.75rem; color: var(--color-secondary);">Online • Typically replies in 5m</div>
              </div>
            </div>
            <button class="modal-close-btn" style="color: #fff;" data-close-modal>&times;</button>
          </div>
          <div class="modal-body" style="padding: 0; height: 380px; display: flex; flex-direction: column;">
            <div id="chat-messages-container" style="flex: 1; padding: 1rem; overflow-y: auto; display: flex; flex-direction: column; gap: 0.75rem; background: #f7f9fa;">
              <!-- Chat Bubble Item -->
            </div>
            <!-- Quick Responses -->
            <div style="padding: 0.5rem 1rem; display: flex; gap: 0.5rem; overflow-x: auto; background: #fff; border-top: 1px solid var(--border-color-light);">
              <button class="btn btn-sm btn-secondary quick-msg-btn">Is this still available?</button>
              <button class="btn btn-sm btn-secondary quick-msg-btn">What is your final price?</button>
              <button class="btn btn-sm btn-secondary quick-msg-btn">Can I inspect it today?</button>
            </div>
            <!-- Input Form -->
            <form id="chat-send-form" style="display: flex; padding: 0.75rem 1rem; background: #fff; border-top: 1px solid var(--border-color-light); gap: 0.5rem;">
              <input type="text" id="chat-input-text" class="filter-input" placeholder="Type your message here..." style="flex: 1;" required>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i></button>
            </form>
          </div>
        </div>
      </div>

      <!-- 4. SHARE MODAL -->
      <div id="modal-share" class="modal-backdrop">
        <div class="modal-dialog">
          <div class="modal-header">
            <h3>Share this Listing</h3>
            <button class="modal-close-btn" data-close-modal>&times;</button>
          </div>
          <div class="modal-body">
            <p style="margin-bottom: 1rem;">Share this amazing deal with your friends and network:</p>
            <div style="display: flex; justify-content: space-around; margin-bottom: 1.5rem;">
              <button id="share-whatsapp" class="btn" style="flex-direction: column; gap: 0.35rem; color: #25d366;">
                <i class="fa-brands fa-whatsapp" style="font-size: 2rem;"></i>
                <span style="font-size: 0.75rem; color: var(--text-primary);">WhatsApp</span>
              </button>
              <button id="share-facebook" class="btn" style="flex-direction: column; gap: 0.35rem; color: #1877f2;">
                <i class="fa-brands fa-facebook" style="font-size: 2rem;"></i>
                <span style="font-size: 0.75rem; color: var(--text-primary);">Facebook</span>
              </button>
              <button id="share-twitter" class="btn" style="flex-direction: column; gap: 0.35rem; color: #1da1f2;">
                <i class="fa-brands fa-x-twitter" style="font-size: 2rem;"></i>
                <span style="font-size: 0.75rem; color: var(--text-primary);">Twitter</span>
              </button>
            </div>

            <div>
              <label style="display: block; font-size: 0.8rem; font-weight: 700; color: var(--text-muted); margin-bottom: 0.35rem;">COPY LINK</label>
              <div style="display: flex; gap: 0.5rem;">
                <input type="text" id="share-link-input" class="filter-input" readonly style="flex: 1; background: var(--bg-subtle);">
                <button id="btn-copy-share-link" class="btn btn-secondary">Copy</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 5. REPORT LISTING MODAL -->
      <div id="modal-report" class="modal-backdrop">
        <div class="modal-dialog">
          <div class="modal-header">
            <h3>Report this Listing</h3>
            <button class="modal-close-btn" data-close-modal>&times;</button>
          </div>
          <div class="modal-body">
            <form id="form-report-listing">
              <p style="font-size: 0.9rem; margin-bottom: 1rem;">Help us keep OLX safe. Why are you reporting this ad?</p>
              <div style="display: flex; flex-direction: column; gap: 0.6rem; margin-bottom: 1.25rem;">
                <label class="filter-checkbox-label"><input type="radio" name="report_reason" value="fraud" checked> Fraudulent or Suspicious Seller</label>
                <label class="filter-checkbox-label"><input type="radio" name="report_reason" value="spam"> Spam / Duplicate Listing</label>
                <label class="filter-checkbox-label"><input type="radio" name="report_reason" value="offensive"> Inappropriate or Offensive Content</label>
                <label class="filter-checkbox-label"><input type="radio" name="report_reason" value="sold"> Item is Already Sold / Unavailable</label>
                <label class="filter-checkbox-label"><input type="radio" name="report_reason" value="price"> Incorrect Pricing or Misleading Info</label>
              </div>
              <div style="margin-bottom: 1.25rem;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">Additional Details (Optional)</label>
                <textarea id="report-notes" class="filter-input" rows="3" placeholder="Describe the issue..."></textarea>
              </div>
              <button type="submit" class="btn btn-danger btn-block">Submit Report</button>
            </form>
          </div>
        </div>
      </div>

      <!-- 6. IMAGE LIGHTBOX ZOOM MODAL -->
      <div id="modal-lightbox" class="modal-backdrop" style="background: rgba(0,0,0,0.9);">
        <div style="position: relative; max-width: 90vw; max-height: 90vh; display: flex; align-items: center; justify-content: center;">
          <button class="modal-close-btn" data-close-modal style="position: absolute; top: -40px; right: 0; color: #fff; font-size: 2rem;">&times;</button>
          <img id="lightbox-img" src="" style="max-width: 90vw; max-height: 85vh; object-fit: contain; border-radius: var(--border-radius-sm);">
        </div>
      </div>
    `;

    document.body.appendChild(modalContainer);
  },

  bindEvents() {
    // Close modal on click of [data-close-modal] or backdrop click
    document.addEventListener('click', (e) => {
      if (e.target.matches('[data-close-modal]') || e.target.closest('[data-close-modal]')) {
        this.closeAll();
      } else if (e.target.classList.contains('modal-backdrop')) {
        this.closeAll();
      }
    });

    // Close modal on ESC key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeAll();
      }
    });

    // Auth Modal Tabs
    const tabLogin = document.getElementById('tab-login-btn');
    const tabRegister = document.getElementById('tab-register-btn');
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');
    const authTitle = document.getElementById('auth-modal-title');

    if (tabLogin && tabRegister) {
      tabLogin.addEventListener('click', () => {
        tabLogin.style.borderBottom = '3px solid var(--color-primary)';
        tabLogin.style.color = 'var(--text-primary)';
        tabRegister.style.borderBottom = 'none';
        tabRegister.style.color = 'var(--text-muted)';
        formLogin.style.display = 'block';
        formRegister.style.display = 'none';
        authTitle.textContent = 'Sign In to OLX';
      });

      tabRegister.addEventListener('click', () => {
        tabRegister.style.borderBottom = '3px solid var(--color-primary)';
        tabRegister.style.color = 'var(--text-primary)';
        tabLogin.style.borderBottom = 'none';
        tabLogin.style.color = 'var(--text-muted)';
        formRegister.style.display = 'block';
        formLogin.style.display = 'none';
        authTitle.textContent = 'Create an OLX Account';
      });
    }

    // Login Form Submit
    if (formLogin) {
      formLogin.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const pass = document.getElementById('login-password').value;
        const res = window.Auth.login(email, pass);
        if (res.success) {
          this.close('modal-auth');
        }
      });
    }

    // Register Form Submit
    if (formRegister) {
      formRegister.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const phone = document.getElementById('reg-phone').value;
        const pass = document.getElementById('reg-password').value;
        const res = window.Auth.register(name, email, phone, pass);
        if (res.success) {
          this.close('modal-auth');
        }
      });
    }

    // Chat Form Submit & Auto-Reply Simulation
    const chatForm = document.getElementById('chat-send-form');
    if (chatForm) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const input = document.getElementById('chat-input-text');
        const text = input.value.trim();
        if (!text) return;

        this.appendChatMessage(text, 'sent');
        input.value = '';

        // Simulate seller auto-reply after 1.2s
        setTimeout(() => {
          const replies = [
            "Hi! Yes, it's available. When would you like to see it?",
            "Hello, yes price is slightly negotiable for genuine buyers.",
            "Thanks for reaching out! You can call me on the number listed in the ad.",
            "Sure, let me know what questions you have about the item."
          ];
          const randomReply = replies[Math.floor(Math.random() * replies.length)];
          this.appendChatMessage(randomReply, 'received');
        }, 1200);
      });

      // Quick Chat Button clicks
      document.querySelectorAll('.quick-msg-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const input = document.getElementById('chat-input-text');
          input.value = btn.textContent;
          chatForm.dispatchEvent(new Event('submit'));
        });
      });
    }

    // Copy Share Link Button
    const copyBtn = document.getElementById('btn-copy-share-link');
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const linkInput = document.getElementById('share-link-input');
        linkInput.select();
        navigator.clipboard.writeText(linkInput.value);
        if (window.App && window.App.showToast) {
          window.App.showToast('Link copied to clipboard!', 'success');
        }
      });
    }

    // Report Form Submit
    const reportForm = document.getElementById('form-report-listing');
    if (reportForm) {
      reportForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.close('modal-report');
        if (window.App && window.App.showToast) {
          window.App.showToast('Thank you. We have received your report and our trust & safety team will review it.', 'info');
        }
      });
    }
  },

  open(modalId) {
    this.closeAll();
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  },

  close(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
    }
    document.body.style.overflow = '';
  },

  closeAll() {
    document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('active'));
    document.body.style.overflow = '';
  },

  openAuthModal(tab = 'login') {
    this.open('modal-auth');
    if (tab === 'register') {
      const regBtn = document.getElementById('tab-register-btn');
      if (regBtn) regBtn.click();
    } else {
      const logBtn = document.getElementById('tab-login-btn');
      if (logBtn) logBtn.click();
    }
  },

  openContactModal(listing) {
    if (!listing) return;
    const nameEl = document.getElementById('contact-seller-name');
    const phoneEl = document.getElementById('contact-seller-phone');
    const callBtn = document.getElementById('btn-call-seller');
    const waBtn = document.getElementById('btn-whatsapp-seller');

    const seller = listing.seller || { name: 'Verified Seller', phone: '+91 98200 12345' };
    if (nameEl) nameEl.textContent = seller.name;
    if (phoneEl) phoneEl.textContent = seller.phone;
    if (callBtn) callBtn.href = `tel:${seller.phone.replace(/\s+/g, '')}`;
    if (waBtn) waBtn.href = `https://wa.me/${seller.phone.replace(/[^0-9]/g, '')}?text=Hi%20${encodeURIComponent(seller.name)},%20I%20am%20interested%20in%20your%20OLX%20listing:%20${encodeURIComponent(listing.title)}`;

    this.open('modal-contact-seller');
  },

  openChatModal(listing) {
    if (!listing) return;
    const seller = listing.seller || { name: 'Seller', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80' };
    const nameEl = document.getElementById('chat-seller-name');
    const avatarEl = document.getElementById('chat-seller-avatar');
    const msgsContainer = document.getElementById('chat-messages-container');

    if (nameEl) nameEl.textContent = seller.name;
    if (avatarEl) avatarEl.src = seller.avatar;
    if (msgsContainer) {
      msgsContainer.innerHTML = `
        <div style="align-self: center; font-size: 0.75rem; color: var(--text-muted); background: #ebedf0; padding: 0.2rem 0.6rem; border-radius: 999px;">
          Ad: ${listing.title.substring(0, 35)}... (${listing.formattedPrice})
        </div>
        <div class="chat-bubble" style="align-self: flex-start; max-width: 75%; background: #fff; padding: 0.65rem 0.85rem; border-radius: 12px 12px 12px 2px; box-shadow: var(--shadow-sm); font-size: 0.9rem;">
          Hello! How can I help you regarding <strong>${listing.title}</strong>?
          <div style="font-size: 0.7rem; color: var(--text-muted); text-align: right; margin-top: 0.2rem;">Just now</div>
        </div>
      `;
    }

    this.open('modal-chat');
  },

  appendChatMessage(text, type = 'sent') {
    const container = document.getElementById('chat-messages-container');
    if (!container) return;

    const isSent = type === 'sent';
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble';
    bubble.style.cssText = `
      align-self: ${isSent ? 'flex-end' : 'flex-start'};
      max-width: 75%;
      background: ${isSent ? 'var(--color-primary)' : '#ffffff'};
      color: ${isSent ? '#ffffff' : 'var(--text-primary)'};
      padding: 0.65rem 0.85rem;
      border-radius: ${isSent ? '12px 12px 2px 12px' : '12px 12px 12px 2px'};
      box-shadow: var(--shadow-sm);
      font-size: 0.9rem;
    `;
    bubble.innerHTML = `
      ${text}
      <div style="font-size: 0.65rem; opacity: 0.75; text-align: right; margin-top: 0.2rem;">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
    `;

    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
  },

  openShareModal(listing) {
    const linkInput = document.getElementById('share-link-input');
    const shareUrl = window.location.href;
    if (linkInput) linkInput.value = shareUrl;

    const waBtn = document.getElementById('share-whatsapp');
    if (waBtn) {
      waBtn.onclick = () => {
        window.open(`https://wa.me/?text=Check%20out%20this%20listing%20on%20OLX:%20${encodeURIComponent(shareUrl)}`, '_blank');
      };
    }

    const fbBtn = document.getElementById('share-facebook');
    if (fbBtn) {
      fbBtn.onclick = () => {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank');
      };
    }

    this.open('modal-share');
  },

  openReportModal(listing) {
    this.open('modal-report');
  },

  openLightbox(imageUrl) {
    const img = document.getElementById('lightbox-img');
    if (img) img.src = imageUrl;
    this.open('modal-lightbox');
  }
};

window.Modal = Modal;
