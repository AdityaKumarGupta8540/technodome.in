/**
 * OLX Global Search & Autocomplete Module
 * Handles location filtering, category hierarchy selection, keyword queries,
 * X/Clear control, autocomplete suggestions, recent searches, and keyboard navigation.
 */

const Search = {
  selectedLocation: 'All India',
  selectedCategory: null,
  selectedCategoryName: 'All Categories',
  selectedSubcategory: null,
  selectedSubcategoryName: null,
  activeSuggestionIndex: -1,

  init() {
    this.bindLocationEvents();
    this.bindCategorySelectorEvents();
    this.bindSearchEvents();
    this.bindClearButtonEvents();
  },

  bindLocationEvents() {
    const locBtn = document.getElementById('header-location-btn');
    const locDropdown = document.getElementById('header-location-dropdown');
    const locText = document.getElementById('selected-location-text');

    if (locBtn && locDropdown) {
      locBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        locDropdown.classList.toggle('active');
        const catDropdown = document.getElementById('search-cat-dropdown');
        if (catDropdown) catDropdown.classList.remove('active');
      });

      // Populate popular locations
      const locations = window.DataStore.getLocations();
      let locHtml = `
        <div class="location-option" data-loc="All India">
          <i class="fa-solid fa-earth-asia"></i> <strong>All India</strong>
        </div>
      `;
      locations.forEach(loc => {
        locHtml += `
          <div class="location-option" data-loc="${loc}">
            <i class="fa-solid fa-location-dot"></i> ${loc}
          </div>
        `;
      });
      locDropdown.innerHTML = locHtml;

      locDropdown.addEventListener('click', (e) => {
        const option = e.target.closest('.location-option');
        if (option) {
          const loc = option.getAttribute('data-loc');
          this.selectedLocation = loc;
          if (locText) locText.textContent = loc;
          locDropdown.classList.remove('active');
          this.triggerSearch();
        }
      });

      document.addEventListener('click', (e) => {
        if (!locBtn.contains(e.target) && !locDropdown.contains(e.target)) {
          locDropdown.classList.remove('active');
        }
      });
    }
  },

  bindCategorySelectorEvents() {
    const catBtn = document.getElementById('search-cat-btn');
    const catDropdown = document.getElementById('search-cat-dropdown');
    const catBtnText = document.getElementById('search-cat-btn-text');

    if (!catBtn || !catDropdown) return;

    // Render complete 13-category hierarchy in dropdown
    const categories = window.DataStore.getCategories();
    let dropdownHtml = `
      <div class="search-cat-item-all ${!this.selectedCategory ? 'active' : ''}" data-cat-slug="" data-sub-slug="" data-name="All Categories">
        <i class="fa-solid fa-layer-group"></i> <strong>All Categories</strong>
      </div>
      <div class="search-cat-divider"></div>
    `;

    categories.forEach(cat => {
      let subHtml = '';
      if (cat.subcategories && cat.subcategories.length > 0) {
        cat.subcategories.forEach(sub => {
          subHtml += `
            <div class="search-cat-subitem" data-cat-slug="${cat.slug}" data-sub-slug="${sub.id}" data-name="${sub.name}" data-parent-name="${cat.name}">
              <i class="${sub.icon || 'fa-solid fa-angle-right'}"></i> <span>${sub.name}</span>
            </div>
          `;
        });
      }

      dropdownHtml += `
        <div class="search-cat-group">
          <div class="search-cat-main-item" data-cat-slug="${cat.slug}" data-sub-slug="" data-name="${cat.name}">
            <div class="search-cat-main-left">
              <i class="${cat.icon}"></i>
              <strong>${cat.name}</strong>
            </div>
            <span class="search-cat-count">${cat.subcategories ? cat.subcategories.length : ''}</span>
          </div>
          ${subHtml ? `<div class="search-cat-subgroup">${subHtml}</div>` : ''}
        </div>
      `;
    });

    catDropdown.innerHTML = dropdownHtml;

    // Toggle dropdown
    catBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isActive = catDropdown.classList.contains('active');
      catDropdown.classList.toggle('active', !isActive);
      catBtn.setAttribute('aria-expanded', !isActive ? 'true' : 'false');
      
      const locDropdown = document.getElementById('header-location-dropdown');
      if (locDropdown) locDropdown.classList.remove('active');
      const sugBox = document.getElementById('search-suggestions-box');
      if (sugBox) sugBox.classList.remove('active');
    });

    // Handle Category / Subcategory Selection
    catDropdown.addEventListener('click', (e) => {
      const allOption = e.target.closest('.search-cat-item-all');
      const mainOption = e.target.closest('.search-cat-main-item');
      const subOption = e.target.closest('.search-cat-subitem');

      if (allOption) {
        this.selectedCategory = null;
        this.selectedCategoryName = 'All Categories';
        this.selectedSubcategory = null;
        this.selectedSubcategoryName = null;
        if (catBtnText) catBtnText.textContent = 'All Categories';
      } else if (subOption) {
        this.selectedCategory = subOption.getAttribute('data-cat-slug');
        this.selectedCategoryName = subOption.getAttribute('data-parent-name');
        this.selectedSubcategory = subOption.getAttribute('data-sub-slug');
        this.selectedSubcategoryName = subOption.getAttribute('data-name');
        if (catBtnText) catBtnText.textContent = this.selectedSubcategoryName;
      } else if (mainOption) {
        this.selectedCategory = mainOption.getAttribute('data-cat-slug');
        this.selectedCategoryName = mainOption.getAttribute('data-name');
        this.selectedSubcategory = null;
        this.selectedSubcategoryName = null;
        if (catBtnText) catBtnText.textContent = this.selectedCategoryName;
      }

      catDropdown.classList.remove('active');
      catBtn.setAttribute('aria-expanded', 'false');
      this.updateClearButtonState();

      // Trigger search/filter with category selection
      this.triggerSearch();
    });

    document.addEventListener('click', (e) => {
      if (!catBtn.contains(e.target) && !catDropdown.contains(e.target)) {
        catDropdown.classList.remove('active');
        catBtn.setAttribute('aria-expanded', 'false');
      }
    });
  },

  bindSearchEvents() {
    const searchInput = document.getElementById('global-search-input');
    const searchBtn = document.getElementById('global-search-btn');
    const suggestionsBox = document.getElementById('search-suggestions-box');

    if (!searchInput) return;

    // Real-time input handling
    searchInput.addEventListener('input', (e) => {
      const term = e.target.value.trim();
      this.updateClearButtonState();
      this.activeSuggestionIndex = -1;

      if (term.length > 0) {
        this.renderSuggestions(term, suggestionsBox);
      } else {
        this.renderRecentSearches(suggestionsBox);
      }
    });

    // Focus handling
    searchInput.addEventListener('focus', () => {
      const term = searchInput.value.trim();
      this.updateClearButtonState();
      this.activeSuggestionIndex = -1;

      if (term.length > 0) {
        this.renderSuggestions(term, suggestionsBox);
      } else {
        this.renderRecentSearches(suggestionsBox);
      }
    });

    // Search button click
    if (searchBtn) {
      searchBtn.addEventListener('click', () => {
        this.executeSearch(searchInput.value);
      });
    }

    // Keyboard navigation (Arrow keys, Enter, Escape)
    searchInput.addEventListener('keydown', (e) => {
      if (!suggestionsBox || !suggestionsBox.classList.contains('active')) {
        if (e.key === 'Enter') {
          this.executeSearch(searchInput.value);
        }
        return;
      }

      const items = suggestionsBox.querySelectorAll('.suggestion-item');

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this.activeSuggestionIndex = (this.activeSuggestionIndex + 1) % items.length;
        this.highlightActiveSuggestion(items);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        this.activeSuggestionIndex = (this.activeSuggestionIndex - 1 + items.length) % items.length;
        this.highlightActiveSuggestion(items);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (this.activeSuggestionIndex >= 0 && items[this.activeSuggestionIndex]) {
          items[this.activeSuggestionIndex].click();
        } else {
          this.executeSearch(searchInput.value);
        }
      } else if (e.key === 'Escape') {
        suggestionsBox.classList.remove('active');
      }
    });

    // Click outside suggestions
    document.addEventListener('click', (e) => {
      if (suggestionsBox && !searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
        suggestionsBox.classList.remove('active');
      }
    });
  },

  highlightActiveSuggestion(items) {
    items.forEach((item, idx) => {
      if (idx === this.activeSuggestionIndex) {
        item.classList.add('active');
        item.scrollIntoView({ block: 'nearest' });
      } else {
        item.classList.remove('active');
      }
    });
  },

  bindClearButtonEvents() {
    const clearBtn = document.getElementById('global-search-clear-btn');
    const searchInput = document.getElementById('global-search-input');
    const catBtnText = document.getElementById('search-cat-btn-text');
    const suggestionsBox = document.getElementById('search-suggestions-box');

    if (!clearBtn || !searchInput) return;

    clearBtn.addEventListener('click', (e) => {
      e.stopPropagation();

      // 1. Clear input text
      searchInput.value = '';

      // 2. Reset Category & Subcategory State
      this.selectedCategory = null;
      this.selectedCategoryName = 'All Categories';
      this.selectedSubcategory = null;
      this.selectedSubcategoryName = null;
      if (catBtnText) catBtnText.textContent = 'All Categories';

      // 3. Hide suggestions & clear button
      if (suggestionsBox) suggestionsBox.classList.remove('active');
      this.updateClearButtonState();

      // 4. Reset dynamic filtering if active on page (without page reload)
      if (window.Filters && typeof window.Filters.applyFilters === 'function') {
        window.Filters.activeFilters = {};
        window.Filters.applyFilters();
      }

      // 5. Focus search input for convenient typing
      searchInput.focus();
    });
  },

  updateClearButtonState() {
    const clearBtn = document.getElementById('global-search-clear-btn');
    const searchInput = document.getElementById('global-search-input');
    if (!clearBtn || !searchInput) return;

    const hasText = searchInput.value.trim().length > 0;
    const hasCategory = this.selectedCategory !== null;

    if (hasText || hasCategory) {
      clearBtn.style.display = 'inline-flex';
    } else {
      clearBtn.style.display = 'none';
    }
  },

  renderRecentSearches(box) {
    if (!box) return;
    const recents = window.DataStore.getRecentSearches();
    if (recents.length === 0) {
      box.classList.remove('active');
      return;
    }

    let html = `
      <div class="suggestion-section">
        <div class="suggestion-title">
          <span><i class="fa-solid fa-clock-rotate-left"></i> Recent Searches</span>
          <button type="button" class="btn-clear-recent-all" id="btn-clear-all-recents" title="Clear all recent searches">Clear All</button>
        </div>
    `;
    recents.forEach(term => {
      html += `
        <div class="suggestion-item" data-search-term="${term}">
          <i class="fa-solid fa-magnifying-glass" style="color: var(--text-muted);"></i>
          <span class="suggestion-term-text">${term}</span>
          <button type="button" class="suggestion-item-remove" data-remove-term="${term}" title="Remove search">&times;</button>
        </div>
      `;
    });
    html += `</div>`;

    box.innerHTML = html;
    box.classList.add('active');
    this.bindSuggestionClicks(box);
  },

  renderSuggestions(term, box) {
    if (!box) return;
    const listings = window.DataStore.getListings();
    const categories = window.DataStore.getCategories();
    const lowerTerm = term.toLowerCase();

    // 1. Match subcategories with parent context
    let matchedSubcategories = [];
    categories.forEach(cat => {
      if (cat.subcategories) {
        cat.subcategories.forEach(sub => {
          if (sub.name.toLowerCase().includes(lowerTerm)) {
            matchedSubcategories.push({
              name: sub.name,
              id: sub.id,
              icon: sub.icon,
              categoryName: cat.name,
              categorySlug: cat.slug
            });
          }
        });
      }
    });
    matchedSubcategories = matchedSubcategories.slice(0, 4);

    // 2. Match major categories
    const matchedCategories = categories.filter(c => 
      c.name.toLowerCase().includes(lowerTerm)
    ).slice(0, 3);

    // 3. Match in listings (filtered by selected category if active)
    let matchedListings = listings.filter(l => {
      const matchesText = l.title.toLowerCase().includes(lowerTerm) || 
                          (l.description && l.description.toLowerCase().includes(lowerTerm));
      const matchesCategory = !this.selectedCategory || l.category === this.selectedCategory;
      return matchesText && matchesCategory;
    }).slice(0, 5);

    if (matchedSubcategories.length === 0 && matchedCategories.length === 0 && matchedListings.length === 0) {
      box.innerHTML = `
        <div class="suggestion-section" style="padding: 1.25rem; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
          <i class="fa-solid fa-magnifying-glass" style="font-size: 1.5rem; margin-bottom: 0.5rem; display: block; opacity: 0.4;"></i>
          No direct results for <strong>"${term}"</strong>
        </div>
      `;
      box.classList.add('active');
      return;
    }

    let html = `<div class="suggestion-section">`;

    // Subcategory matches with category context
    if (matchedSubcategories.length > 0) {
      html += `<div class="suggestion-title"><i class="fa-solid fa-tags"></i> Subcategories & Hubs</div>`;
      matchedSubcategories.forEach(sub => {
        html += `
          <div class="suggestion-item suggestion-subcat-item" data-category-slug="${sub.categorySlug}" data-sub-slug="${sub.id}" data-search-term="${sub.name}">
            <i class="${sub.icon || 'fa-solid fa-tag'}" style="color: var(--color-accent);"></i>
            <span><strong>${sub.name}</strong> <span style="font-size: 0.78rem; color: var(--text-muted); font-weight: 500;">in ${sub.categoryName}</span></span>
            <span class="suggestion-badge">Explore Hub</span>
          </div>
        `;
      });
    }

    // Major category matches
    if (matchedCategories.length > 0) {
      html += `<div class="suggestion-title"><i class="fa-solid fa-layer-group"></i> Major Categories</div>`;
      matchedCategories.forEach(cat => {
        html += `
          <div class="suggestion-item" data-category-slug="${cat.slug}" data-search-term="${cat.name}">
            <i class="${cat.icon}" style="color: var(--color-primary);"></i>
            <span><strong>${cat.name}</strong></span>
            <span class="suggestion-badge">Category</span>
          </div>
        `;
      });
    }

    // Listing Ad matches
    if (matchedListings.length > 0) {
      html += `<div class="suggestion-title"><i class="fa-solid fa-list-check"></i> Matching Ads</div>`;
      matchedListings.forEach(l => {
        html += `
          <div class="suggestion-item suggestion-ad-item" data-listing-id="${l.id}" data-search-term="${l.title}">
            <i class="fa-solid fa-magnifying-glass" style="color: var(--text-muted);"></i>
            <span class="suggestion-ad-title">${l.title}</span>
            <span class="suggestion-ad-price">${l.formattedPrice}</span>
          </div>
        `;
      });
    }

    html += `</div>`;
    box.innerHTML = html;
    box.classList.add('active');
    this.bindSuggestionClicks(box);
  },

  bindSuggestionClicks(box) {
    // Clear all recents
    const clearAllBtn = box.querySelector('#btn-clear-all-recents');
    if (clearAllBtn) {
      clearAllBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        localStorage.removeItem('olx_recent_searches');
        box.classList.remove('active');
      });
    }

    // Remove single recent item
    box.querySelectorAll('.suggestion-item-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const term = btn.getAttribute('data-remove-term');
        const recents = window.DataStore.getRecentSearches().filter(t => t !== term);
        localStorage.setItem('olx_recent_searches', JSON.stringify(recents));
        this.renderRecentSearches(box);
      });
    });

    // Item click
    box.querySelectorAll('.suggestion-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (e.target.closest('.suggestion-item-remove')) return;

        const catSlug = item.getAttribute('data-category-slug');
        const subSlug = item.getAttribute('data-sub-slug');
        const listingId = item.getAttribute('data-listing-id');
        const term = item.getAttribute('data-search-term');

        const basePath = window.App.getBasePath();

        if (listingId) {
          window.location.href = `${basePath}pages/listing-details.html?id=${listingId}`;
        } else if (subSlug && catSlug) {
          window.location.href = `${basePath}categories/${catSlug}.html?sub=${subSlug}`;
        } else if (catSlug) {
          window.location.href = `${basePath}categories/${catSlug}.html`;
        } else if (term) {
          const searchInput = document.getElementById('global-search-input');
          if (searchInput) searchInput.value = term;
          this.executeSearch(term);
        }
        box.classList.remove('active');
      });
    });
  },

  executeSearch(term) {
    const cleanTerm = (term || '').trim();
    if (cleanTerm) {
      window.DataStore.addRecentSearch(cleanTerm);
    }

    const currentPath = window.location.pathname;
    const basePath = window.App.getBasePath();

    // If on homepage or page with Filters, apply dynamically
    if (window.Filters && typeof window.Filters.applyFilters === 'function') {
      window.Filters.activeFilters.query = cleanTerm;
      if (this.selectedCategory) {
        window.Filters.currentCategory = this.selectedCategory;
      }
      if (this.selectedSubcategory) {
        window.Filters.currentSubcategory = this.selectedSubcategory;
      }
      window.Filters.applyFilters();
    } else {
      // Build query URL
      let url = `${basePath}index.html?q=${encodeURIComponent(cleanTerm)}`;
      if (this.selectedCategory) {
        url += `&cat=${encodeURIComponent(this.selectedCategory)}`;
      }
      if (this.selectedSubcategory) {
        url += `&sub=${encodeURIComponent(this.selectedSubcategory)}`;
      }
      if (this.selectedLocation && this.selectedLocation !== 'All India') {
        url += `&loc=${encodeURIComponent(this.selectedLocation)}`;
      }
      window.location.href = url;
    }

    const sugBox = document.getElementById('search-suggestions-box');
    if (sugBox) sugBox.classList.remove('active');
  },

  triggerSearch() {
    const searchInput = document.getElementById('global-search-input');
    const term = searchInput ? searchInput.value : '';
    this.executeSearch(term);
  },

  getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    return {
      query: params.get('q') || '',
      category: params.get('cat') || '',
      subcategory: params.get('sub') || '',
      location: params.get('loc') || '',
      minPrice: params.get('min_price') || '',
      maxPrice: params.get('max_price') || '',
      sort: params.get('sort') || 'newest',
      id: params.get('id') || ''
    };
  }
};

window.Search = Search;
