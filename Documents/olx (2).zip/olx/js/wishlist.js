/**
 * OLX Wishlist Module
 * Handles wishlist toggles, counter badge updates, and wishlist page rendering.
 */

const Wishlist = {
  init() {
    this.updateBadge();
    window.addEventListener('wishlistUpdated', () => {
      this.updateBadge();
    });
  },

  getWishlist() {
    return window.DataStore.getWishlist();
  },

  isWishlisted(id) {
    return window.DataStore.isWishlisted(id);
  },

  toggle(id) {
    const isAdded = window.DataStore.toggleWishlist(id);
    const listing = window.DataStore.getListingById(id);
    const title = listing ? listing.title : 'Item';

    if (window.App && window.App.showToast) {
      if (isAdded) {
        window.App.showToast(`"${title.substring(0, 24)}..." added to Wishlist!`, 'success');
      } else {
        window.App.showToast(`Removed from Wishlist.`, 'info');
      }
    }

    // Update all heart icons matching this id
    document.querySelectorAll(`.card-heart-btn[data-id="${id}"]`).forEach(btn => {
      if (isAdded) {
        btn.classList.add('active');
        btn.innerHTML = '<i class="fa-solid fa-heart"></i>';
      } else {
        btn.classList.remove('active');
        btn.innerHTML = '<i class="fa-regular fa-heart"></i>';
      }
    });

    return isAdded;
  },

  updateBadge() {
    const count = this.getWishlist().length;
    document.querySelectorAll('.wishlist-badge-count').forEach(badge => {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    });
  },

  renderWishlistPage(containerId = 'wishlist-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const wishlistIds = this.getWishlist();
    const allListings = window.DataStore.getListings();
    const wishlistItems = allListings.filter(item => wishlistIds.includes(item.id));

    if (wishlistItems.length === 0) {
      container.innerHTML = `
        <div class="empty-state text-center" style="padding: 4rem 1rem;">
          <div style="font-size: 4rem; color: var(--text-muted); margin-bottom: 1rem;">
            <i class="fa-regular fa-heart"></i>
          </div>
          <h2 style="margin-bottom: 0.5rem;">Your Wishlist is Empty</h2>
          <p style="margin-bottom: 1.5rem;">You haven't saved any ads yet. Browse categories or listings to find what you love!</p>
          <a href="${window.App.getBasePath()}index.html" class="btn btn-primary btn-lg">Explore Marketplace</a>
        </div>
      `;
      return;
    }

    let html = `<div class="grid-listings">`;
    wishlistItems.forEach(item => {
      html += window.Listings.createCardHtml(item);
    });
    html += `</div>`;
    container.innerHTML = html;
  }
};

window.Wishlist = Wishlist;
