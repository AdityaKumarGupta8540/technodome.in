/**
 * OLX App Core Initializer & UI Component Injector
 * Handles global navigation, header/footer injection, toast alerts, and layout listeners.
 */

const App = {
  getBasePath() {
    const path = window.location.pathname;
    if (path.includes('/categories/') || path.includes('/pages/')) {
      return '../';
    }
    return './';
  },

  init() {
    this.injectHeader();
    this.injectCategoryBar();
    this.injectMobileDrawer();
    this.injectMobileBottomNav();
    this.injectFooter();
    this.injectToastContainer();

    // Initialize sub-modules
    if (window.DataStore) window.DataStore.init();
    if (window.Modal) window.Modal.init();
    if (window.Auth) {
      this.updateHeaderAuth();
      window.addEventListener('authStateChanged', () => this.updateHeaderAuth());
    }
    if (window.Wishlist) window.Wishlist.init();
    if (window.Search) window.Search.init();

    this.bindGlobalEvents();
  },

  injectHeader() {
    const headerEl = document.getElementById('site-header-root');
    if (!headerEl) return;

    const basePath = this.getBasePath();

    headerEl.innerHTML = `
      <header class="site-header">
        <div class="container header-container">
          <!-- Mobile Hamburger -->
          <button class="mobile-nav-toggle" id="btn-mobile-menu-toggle" aria-label="Open Navigation Menu">
            <i class="fa-solid fa-bars"></i>
          </button>

          <!-- Logo -->
          <a href="${basePath}index.html" class="header-logo" title="OLX Marketplace">
            <i class="fa-solid fa-cube"></i> OLX<span>.</span>
          </a>

          <!-- Location Selector -->
          <div class="location-selector">
            <button class="location-btn" id="header-location-btn">
              <span class="truncate"><i class="fa-solid fa-location-dot"></i> <span id="selected-location-text">All India</span></span>
              <i class="fa-solid fa-chevron-down" style="font-size: 0.75rem;"></i>
            </button>
            <div class="location-dropdown" id="header-location-dropdown"></div>
          </div>

          <!-- Global Search with Category Selector & Clear Option -->
          <div class="global-search">
            <div class="search-input-wrapper">
              
              <!-- Search Category Selector Dropdown -->
              <div class="search-cat-selector" id="search-cat-selector">
                <button type="button" class="search-cat-btn" id="search-cat-btn" aria-haspopup="true" aria-expanded="false" title="Filter by category">
                  <i class="fa-solid fa-layer-group search-cat-btn-icon"></i>
                  <span class="search-cat-text truncate" id="search-cat-btn-text">All Categories</span>
                  <i class="fa-solid fa-chevron-down search-cat-chevron"></i>
                </button>
                <div class="search-cat-dropdown" id="search-cat-dropdown" role="menu"></div>
              </div>

              <!-- Input -->
              <input type="text" id="global-search-input" class="search-input" placeholder="Find Cars, Mobile Phones, Real Estate, Jobs and more..." autocomplete="off">

              <!-- X / Clear Button -->
              <button type="button" class="search-clear-btn" id="global-search-clear-btn" aria-label="Clear search and category" title="Clear search" style="display: none;">
                <i class="fa-solid fa-xmark"></i>
              </button>

              <!-- Submit -->
              <button type="button" class="search-btn" id="global-search-btn" aria-label="Search">
                <i class="fa-solid fa-magnifying-glass"></i>
              </button>
            </div>
            
            <!-- Dynamic Autocomplete Suggestions -->
            <div class="search-suggestions" id="search-suggestions-box"></div>
          </div>

          <!-- Actions: Wishlist, Login, SELL CTA -->
          <div class="header-actions">
            <!-- Wishlist Heart -->
            <a href="${basePath}pages/wishlist.html" class="wishlist-link" title="My Wishlist">
              <i class="fa-regular fa-heart"></i>
              <span class="badge-count wishlist-badge-count" style="display: none;">0</span>
            </a>

            <!-- Auth Container (Login Link / Profile Dropdown) -->
            <div id="header-auth-container">
              <button class="auth-btn" onclick="window.Modal.openAuthModal('login')">Login</button>
            </div>

            <!-- Highlighted SELL CTA Button -->
            <a href="${basePath}pages/sell.html" class="btn-sell">
              <i class="fa-solid fa-plus"></i> SELL
            </a>
          </div>
        </div>
      </header>
    `;
  },

  injectCategoryBar() {
    const navEl = document.getElementById('category-nav-root');
    if (!navEl) return;

    const basePath = this.getBasePath();
    const categories = window.DataStore.getCategories();

    // Generate Mega Menu Grid with complete 13 categories hierarchy
    let megaGridHtml = '';
    categories.forEach(cat => {
      let subcatsHtml = '';
      if (cat.subcategories && cat.subcategories.length > 0) {
        cat.subcategories.forEach(sub => {
          subcatsHtml += `
            <li class="mega-subcat-item">
              <a href="${basePath}categories/${cat.slug}.html?sub=${sub.id}" class="mega-subcat-link">
                <i class="${sub.icon || 'fa-solid fa-angle-right'}"></i>
                <span>${sub.name}</span>
              </a>
            </li>
          `;
        });
      }

      megaGridHtml += `
        <div class="mega-cat-card">
          <a href="${basePath}categories/${cat.slug}.html" class="mega-cat-header" title="${cat.name}">
            <div class="mega-cat-icon">
              <i class="${cat.icon}"></i>
            </div>
            <span class="mega-cat-name">${cat.name}</span>
          </a>
          <ul class="mega-subcat-list">
            ${subcatsHtml}
          </ul>
        </div>
      `;
    });

    navEl.innerHTML = `
      <nav class="category-nav-bar" aria-label="Marketplace Categories">
        <div class="container category-nav-container">
          <div class="all-cats-mega-wrapper" id="all-cats-mega-wrapper">
            <button type="button" class="all-cats-btn" id="btn-all-categories" aria-expanded="false" aria-haspopup="true" aria-controls="mega-menu-dropdown">
              <span class="all-cats-label">ALL CATEGORIES</span>
              <i class="fa-solid fa-chevron-down all-cats-chevron"></i>
            </button>
            
            <!-- Interactive Responsive Mega Menu Dropdown -->
            <div class="mega-menu-dropdown" id="mega-menu-dropdown" role="menu">
              <div class="mega-menu-top-bar">
                <div class="mega-menu-title">
                  <i class="fa-solid fa-layer-group"></i> Browse All 13 Categories & Hubs
                </div>
                <span class="mega-menu-count">${categories.length} Categories</span>
              </div>
              <div class="mega-menu-grid">
                ${megaGridHtml}
              </div>
            </div>
          </div>
        </div>
      </nav>
    `;

    this.bindMegaMenuEvents();
  },

  bindMegaMenuEvents() {
    const wrapper = document.getElementById('all-cats-mega-wrapper');
    const toggleBtn = document.getElementById('btn-all-categories');
    const megaDropdown = document.getElementById('mega-menu-dropdown');

    if (!wrapper || !toggleBtn || !megaDropdown) return;

    const openMenu = () => {
      wrapper.classList.add('active');
      toggleBtn.setAttribute('aria-expanded', 'true');
    };

    const closeMenu = () => {
      wrapper.classList.remove('active');
      toggleBtn.setAttribute('aria-expanded', 'false');
    };

    const toggleMenu = (e) => {
      e.stopPropagation();
      if (wrapper.classList.contains('active')) {
        closeMenu();
      } else {
        openMenu();
      }
    };

    toggleBtn.addEventListener('click', toggleMenu);

    // Close on click outside
    document.addEventListener('click', (e) => {
      if (!wrapper.contains(e.target)) {
        closeMenu();
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && wrapper.classList.contains('active')) {
        closeMenu();
        toggleBtn.focus();
      }
    });

    // Close when link clicked inside mega menu
    megaDropdown.addEventListener('click', (e) => {
      if (e.target.closest('a')) {
        closeMenu();
      }
    });
  },

  injectMobileDrawer() {
    if (document.getElementById('mobile-drawer-root')) return;

    const basePath = this.getBasePath();
    const categories = window.DataStore.getCategories();

    let catLinks = '';
    categories.forEach(c => {
      catLinks += `
        <a href="${basePath}categories/${c.slug}.html" class="mobile-drawer-link">
          <i class="${c.icon}"></i> ${c.name}
        </a>
      `;
    });

    const drawer = document.createElement('div');
    drawer.id = 'mobile-drawer-root';
    drawer.innerHTML = `
      <div class="mobile-drawer-backdrop" id="mobile-drawer-backdrop"></div>
      <aside class="mobile-drawer" id="mobile-drawer-panel">
        <div class="mobile-drawer-header">
          <div style="display: flex; align-items: center; gap: 0.5rem; font-weight: 800; font-size: 1.25rem;">
            <i class="fa-solid fa-cube"></i> OLX Menu
          </div>
          <button id="btn-close-drawer" style="color: #fff; font-size: 1.5rem;">&times;</button>
        </div>
        <div class="mobile-drawer-body">
          <div style="padding: 0.75rem 1.25rem; font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">
            Marketplace Categories
          </div>
          ${catLinks}
          <div style="padding: 0.75rem 1.25rem; font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-top: 1rem;">
            My Account
          </div>
          <a href="${basePath}pages/profile.html" class="mobile-drawer-link"><i class="fa-solid fa-user"></i> My Profile & Ads</a>
          <a href="${basePath}pages/wishlist.html" class="mobile-drawer-link"><i class="fa-solid fa-heart"></i> Saved Favorites</a>
          <a href="${basePath}pages/sell.html" class="mobile-drawer-link"><i class="fa-solid fa-plus-circle"></i> Post New Ad</a>
        </div>
      </aside>
    `;

    document.body.appendChild(drawer);
  },

  injectMobileBottomNav() {
    if (document.getElementById('mobile-bottom-nav-root')) return;

    const basePath = this.getBasePath();
    const currentPath = window.location.pathname;

    const bottomNav = document.createElement('nav');
    bottomNav.id = 'mobile-bottom-nav-root';
    bottomNav.className = 'mobile-bottom-nav';
    bottomNav.innerHTML = `
      <a href="${basePath}index.html" class="mobile-bottom-nav-item ${currentPath.endsWith('index.html') || currentPath.endsWith('/') ? 'active' : ''}">
        <i class="fa-solid fa-house"></i>
        <span>Home</span>
      </a>
      <a href="${basePath}pages/wishlist.html" class="mobile-bottom-nav-item ${currentPath.includes('wishlist.html') ? 'active' : ''}">
        <i class="fa-solid fa-heart"></i>
        <span>Wishlist</span>
      </a>
      <a href="${basePath}pages/sell.html" class="mobile-bottom-nav-item mobile-sell-btn">
        <div class="sell-circle">
          <i class="fa-solid fa-plus"></i>
        </div>
        <span>SELL</span>
      </a>
      <a href="javascript:void(0)" onclick="window.Modal.openAuthModal('login')" class="mobile-bottom-nav-item">
        <i class="fa-solid fa-comments"></i>
        <span>Chat</span>
      </a>
      <a href="${basePath}pages/profile.html" class="mobile-bottom-nav-item ${currentPath.includes('profile.html') ? 'active' : ''}">
        <i class="fa-solid fa-user"></i>
        <span>Profile</span>
      </a>
    `;

    document.body.appendChild(bottomNav);
  },

  injectFooter() {
    const footerEl = document.getElementById('site-footer-root');
    if (!footerEl) return;

    const basePath = this.getBasePath();

    footerEl.innerHTML = `
      <footer class="site-footer">
        <div class="container">
          <div class="footer-grid">
            <!-- Col 1: Brand -->
            <div class="footer-col">
              <div class="header-logo" style="color: #fff; margin-bottom: 0.75rem;">
                <i class="fa-solid fa-cube" style="color: var(--color-saffron);"></i> OLX<span style="color: var(--color-green-light);">.</span>
              </div>
              <p style="color: #90a4ae; font-size: 0.85rem; line-height: 1.6; margin-bottom: 1rem;">
                The leading next-generation classifieds marketplace connecting millions of buyers and sellers across Real Estate, Vehicles, Jobs, Electronics, and Services.
              </p>
              <div style="display: flex; gap: 0.75rem; font-size: 1.25rem;">
                <a href="#" style="color: #90a4ae;"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" style="color: #90a4ae;"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" style="color: #90a4ae;"><i class="fa-brands fa-x-twitter"></i></a>
                <a href="#" style="color: #90a4ae;"><i class="fa-brands fa-youtube"></i></a>
              </div>
            </div>

            <!-- Col 2: Popular Categories -->
            <div class="footer-col">
              <h4>Popular Categories</h4>
              <ul>
                <li><a href="${basePath}categories/real-estate.html">Real Estate & Plots</a></li>
                <li><a href="${basePath}categories/vehicles.html">Cars & Motorbikes</a></li>
                <li><a href="${basePath}categories/electronics.html">Mobile Phones & Laptops</a></li>
                <li><a href="${basePath}categories/jobs.html">Remote & Tech Jobs</a></li>
                <li><a href="${basePath}categories/home-furniture.html">Home & Furniture</a></li>
              </ul>
            </div>

            <!-- Col 3: More Categories -->
            <div class="footer-col">
              <h4>More Categories</h4>
              <ul>
                <li><a href="${basePath}categories/fashion.html">Fashion & Lifestyle</a></li>
                <li><a href="${basePath}categories/education.html">Courses & Tutors</a></li>
                <li><a href="${basePath}categories/services.html">Professional Services</a></li>
                <li><a href="${basePath}categories/tourism.html">Tourism & Hotels</a></li>
                <li><a href="${basePath}categories/agriculture.html">Agriculture & Tractors</a></li>
              </ul>
            </div>

            <!-- Col 4: Trending Locations -->
            <div class="footer-col">
              <h4>Trending Locations</h4>
              <ul>
                <li><a href="${basePath}index.html?loc=Mumbai">Mumbai</a></li>
                <li><a href="${basePath}index.html?loc=Delhi">Delhi NCR</a></li>
                <li><a href="${basePath}index.html?loc=Bengaluru">Bengaluru</a></li>
                <li><a href="${basePath}index.html?loc=Hyderabad">Hyderabad</a></li>
                <li><a href="${basePath}index.html?loc=Pune">Pune</a></li>
              </ul>
            </div>

            <!-- Col 5: OLX App & Help -->
            <div class="footer-col">
              <h4>OLX Marketplace App</h4>
              <p style="color: #90a4ae; font-size: 0.85rem; margin-bottom: 0.75rem;">
                Buy & sell on the go with real-time push alerts and lightning-fast search.
              </p>
              <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                <a href="#" class="btn btn-sm btn-secondary" style="color: #fff; border-color: rgba(255,255,255,0.3);"><i class="fa-brands fa-apple"></i> App Store</a>
                <a href="#" class="btn btn-sm btn-secondary" style="color: #fff; border-color: rgba(255,255,255,0.3);"><i class="fa-brands fa-google-play"></i> Google Play</a>
              </div>
            </div>
          </div>

          <div class="footer-bottom">
            <div>
              <span>Free Classifieds in India. &copy; 2026 OLX Marketplace Clone. All rights reserved.</span>
            </div>
            <div style="display: flex; gap: 1.5rem;">
              <a href="#" style="color: #90a4ae;">Help & Support</a>
              <a href="#" style="color: #90a4ae;">Terms of Use</a>
              <a href="#" style="color: #90a4ae;">Privacy Policy</a>
            </div>
          </div>
        </div>
      </footer>
    `;
  },

  injectToastContainer() {
    if (document.getElementById('global-toast-container')) return;
    const toastBox = document.createElement('div');
    toastBox.id = 'global-toast-container';
    toastBox.className = 'toast-container';
    document.body.appendChild(toastBox);
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('global-toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'fa-solid fa-circle-info';
    if (type === 'success') icon = 'fa-solid fa-circle-check';
    if (type === 'error') icon = 'fa-solid fa-triangle-exclamation';

    toast.innerHTML = `
      <i class="${icon}"></i>
      <span style="flex: 1;">${message}</span>
      <button style="color: inherit; opacity: 0.7; font-size: 1.1rem; cursor: pointer;" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 300ms ease';
        setTimeout(() => toast.remove(), 300);
      }
    }, 3500);
  },

  updateHeaderAuth() {
    const container = document.getElementById('header-auth-container');
    if (!container) return;

    const user = window.DataStore.getCurrentUser();
    const basePath = this.getBasePath();

    if (user) {
      container.innerHTML = `
        <div class="user-profile-menu">
          <div class="profile-avatar-btn" id="header-avatar-btn">
            <img src="${user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}" class="avatar-img" alt="${user.name}">
            <i class="fa-solid fa-chevron-down" style="font-size: 0.7rem; color: var(--color-primary);"></i>
          </div>
          <div class="profile-dropdown" id="header-profile-dropdown">
            <div class="dropdown-user-info">
              <div style="font-weight: 700; color: var(--text-primary);">${user.name}</div>
              <div style="font-size: 0.75rem; color: var(--text-muted);">${user.email}</div>
            </div>
            <a href="${basePath}pages/profile.html" class="dropdown-link"><i class="fa-solid fa-user"></i> My Profile & Ads</a>
            <a href="${basePath}pages/wishlist.html" class="dropdown-link"><i class="fa-solid fa-heart"></i> Saved Favorites</a>
            <a href="${basePath}pages/sell.html" class="dropdown-link"><i class="fa-solid fa-plus-circle"></i> Post New Ad</a>
            <a href="javascript:void(0)" onclick="window.Auth.logout()" class="dropdown-link" style="color: var(--color-danger); border-top: 1px solid var(--border-color-light);">
              <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
          </div>
        </div>
      `;

      const avatarBtn = document.getElementById('header-avatar-btn');
      const profileDropdown = document.getElementById('header-profile-dropdown');
      if (avatarBtn && profileDropdown) {
        avatarBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          profileDropdown.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
          if (!avatarBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('active');
          }
        });
      }
    } else {
      container.innerHTML = `
        <button class="auth-btn" onclick="window.Modal.openAuthModal('login')">Login</button>
      `;
    }
  },

  bindGlobalEvents() {
    // Mobile Drawer Toggle
    const toggleBtn = document.getElementById('btn-mobile-menu-toggle');
    const drawerBackdrop = document.getElementById('mobile-drawer-backdrop');
    const drawerPanel = document.getElementById('mobile-drawer-panel');
    const closeBtn = document.getElementById('btn-close-drawer');

    if (toggleBtn && drawerPanel && drawerBackdrop) {
      const openDrawer = () => {
        drawerBackdrop.classList.add('active');
        drawerPanel.classList.add('active');
      };
      const closeDrawer = () => {
        drawerBackdrop.classList.remove('active');
        drawerPanel.classList.remove('active');
      };

      toggleBtn.addEventListener('click', openDrawer);
      if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
      drawerBackdrop.addEventListener('click', closeDrawer);
    }
  }
};

window.App = App;

// Bootstrap on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
