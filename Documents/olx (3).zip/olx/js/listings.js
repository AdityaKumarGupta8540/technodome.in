/**
 * OLX Listings Renderer & Single Listing View Module
 * Handles card rendering, details page view, image zoom, and related listings.
 */

const Listings = {
  createCardHtml(listing) {
    const isSaved = window.DataStore.isWishlisted(listing.id);
    const basePath = window.App ? window.App.getBasePath() : './';
    const detailUrl = `${basePath}pages/listing-details.html?id=${listing.id}`;
    const mainImg = listing.images && listing.images.length > 0 
      ? listing.images[0] 
      : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';

    let specsHtml = '';
    if (listing.specs && Object.keys(listing.specs).length > 0) {
      const specVals = Object.values(listing.specs).slice(0, 2);
      specsHtml = specVals.map(val => `<span class="card-spec-tag">${val}</span>`).join('');
    } else {
      specsHtml = `<span class="card-spec-tag">${listing.subcategory || listing.category}</span>`;
    }

    return `
      <div class="listing-card ${listing.featured ? 'featured-card' : ''}" data-listing-id="${listing.id}">
        <div class="card-img-wrap">
          <a href="${detailUrl}" class="card-img-link" tabindex="-1">
            <img src="${mainImg}" alt="${listing.title}" class="card-img" loading="lazy">
          </a>
          ${listing.featured ? `
            <div class="card-badge-featured">
              <i class="fa-solid fa-bolt"></i> Featured
            </div>
            <div class="card-badge-verified">
              <i class="fa-solid fa-circle-check"></i> Verified
            </div>
          ` : ''}
          <button class="card-heart-btn ${isSaved ? 'active' : ''}" data-id="${listing.id}" title="Save to Wishlist" onclick="window.Wishlist.toggle('${listing.id}')" aria-label="Save ${listing.title} to wishlist">
            <i class="${isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
          </button>
        </div>
        <div class="card-body">
          <div class="card-price-row">
            <div class="card-price">${listing.formattedPrice}</div>
            ${listing.featured ? '<span class="card-tag-premium"><i class="fa-solid fa-crown"></i> Top Ad</span>' : ''}
          </div>
          <h3 class="card-title line-clamp-2">
            <a href="${detailUrl}" title="${listing.title}">${listing.title}</a>
          </h3>
          <div class="card-meta-tags">
            ${specsHtml}
          </div>
          <div class="card-footer">
            <span class="truncate"><i class="fa-solid fa-location-dot"></i> ${listing.locality || listing.location}</span>
            <span><i class="fa-regular fa-clock" style="font-size: 0.72rem;"></i> ${listing.postedDate}</span>
          </div>
        </div>
      </div>
    `;
  },

  createDealCardHtml(deal) {
    const isSaved = window.DataStore ? window.DataStore.isWishlisted(deal.id) : false;
    const basePath = window.App ? window.App.getBasePath() : './';
    const detailUrl = `${basePath}pages/listing-details.html?id=${deal.id}`;
    const mainImg = deal.images && deal.images.length > 0 
      ? deal.images[0] 
      : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';
    const discount = deal.discountPercent ? `${deal.discountPercent}% OFF` : (deal.dealBadge || 'HOT DEAL');
    const originalPriceFormatted = deal.formattedOriginalPrice || (deal.originalPrice ? `₹ ${Number(deal.originalPrice).toLocaleString('en-IN')}` : '');
    const savingsFormatted = deal.originalPrice && deal.price ? `Save ₹ ${(deal.originalPrice - deal.price).toLocaleString('en-IN')}` : '';
    const claimedPercent = deal.claimedPercent || 78;

    return `
      <div class="deal-card" data-listing-id="${deal.id}">
        <div class="deal-card-media">
          <a href="${detailUrl}" class="deal-card-img-link" tabindex="-1">
            <img src="${mainImg}" alt="${deal.title}" class="deal-card-img" loading="lazy">
          </a>
          <span class="deal-badge-discount">
            <i class="fa-solid fa-fire"></i> ${discount}
          </span>
          <button class="card-heart-btn ${isSaved ? 'active' : ''}" data-id="${deal.id}" title="Save to Wishlist" onclick="window.Wishlist.toggle('${deal.id}')" aria-label="Save ${deal.title} to wishlist">
            <i class="${isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
          </button>
          <div class="deal-tag-ends">
            <i class="fa-regular fa-clock"></i> Limited Time
          </div>
        </div>

        <div class="deal-card-body">
          <div class="deal-price-row">
            <div class="deal-current-price">${deal.formattedPrice}</div>
            ${originalPriceFormatted ? `<div class="deal-original-price">${originalPriceFormatted}</div>` : ''}
          </div>
          ${savingsFormatted ? `<div class="deal-save-badge"><i class="fa-solid fa-tag"></i> ${savingsFormatted}</div>` : ''}

          <h3 class="deal-card-title">
            <a href="${detailUrl}" title="${deal.title}">${deal.title}</a>
          </h3>

          <div class="deal-meta-info">
            <span class="truncate"><i class="fa-solid fa-location-dot"></i> ${deal.locality || deal.location}</span>
            <span class="deal-cat-tag"><i class="fa-solid fa-layer-group"></i> ${deal.subcategory || deal.category}</span>
          </div>

          <div class="deal-progress-container">
            <div class="deal-progress-bar">
              <div class="deal-progress-fill" style="width: ${claimedPercent}%;"></div>
            </div>
            <div class="deal-progress-label">
              <span><i class="fa-solid fa-bolt" style="color: #f59e0b;"></i> ${claimedPercent}% Claimed</span>
              <span class="deal-hurry-text">Selling Fast</span>
            </div>
          </div>

          <a href="${detailUrl}" class="deal-cta-btn">
            <span>View Deal</span>
            <i class="fa-solid fa-arrow-right"></i>
          </a>
        </div>
      </div>
    `;
  },

  renderHotDeals(containerId = 'home-hot-deals-grid') {
    const container = document.getElementById(containerId);
    if (!container) return;
    const deals = window.DataStore ? window.DataStore.getHotDeals() : [];
    let html = '';
    deals.forEach(deal => {
      html += this.createDealCardHtml(deal);
    });
    container.innerHTML = html;
  },

  renderDetailsPage() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const container = document.getElementById('listing-details-container');
    if (!container) return;

    if (!id) {
      container.innerHTML = `
        <div class="empty-state text-center" style="padding: 4rem 1rem;">
          <h2>No Listing Specified</h2>
          <p>Please select a listing from the marketplace to view details.</p>
          <a href="../index.html" class="btn btn-primary mt-4">Browse Marketplace</a>
        </div>
      `;
      return;
    }

    const listing = window.DataStore.getListingById(id);
    if (!listing) {
      container.innerHTML = `
        <div class="empty-state text-center" style="padding: 4rem 1rem;">
          <h2>Listing Not Found</h2>
          <p>The ad you are looking for might have been sold or removed.</p>
          <a href="../index.html" class="btn btn-primary mt-4">Return Home</a>
        </div>
      `;
      return;
    }

    // Save to recently viewed
    this.addRecentlyViewed(listing.id);

    const category = window.DataStore.getCategoryBySlug(listing.category) || { name: listing.category, slug: listing.category };
    const isVehicle = listing.category === 'vehicles' || listing.subcategory === 'cars' || listing.subcategory === 'bikes' || (listing.specs && (listing.specs.fuel || listing.specs.brand || listing.specs.kmDriven));

    // Ensure 5-8 gallery images
    let images = listing.images && listing.images.length >= 5 ? listing.images : [];
    if (images.length < 5) {
      const fallbackVehicle = [
        'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1619682817481-e994891cd1f5?auto=format&fit=crop&w=1200&q=80'
      ];
      const fallbackGeneral = [
        'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80'
      ];
      const pool = isVehicle ? fallbackVehicle : fallbackGeneral;
      const combined = [...(listing.images || []), ...pool];
      images = Array.from(new Set(combined)).slice(0, 7);
    }

    const isSaved = window.DataStore.isWishlisted(listing.id);

    // Breadcrumbs
    const breadcrumbsHtml = `
      <nav class="breadcrumbs">
        <a href="../index.html"><i class="fa-solid fa-house"></i> Home</a>
        <i class="fa-solid fa-chevron-right" style="font-size: 0.65rem;"></i>
        <a href="../categories/${category.slug}.html">${category.name}</a>
        <i class="fa-solid fa-chevron-right" style="font-size: 0.65rem;"></i>
        <span class="current truncate">${listing.title}</span>
      </nav>
    `;

    // Gallery Thumbnails
    let thumbsHtml = '';
    images.forEach((img, index) => {
      thumbsHtml += `
        <div class="thumb-item ${index === 0 ? 'active' : ''}" data-index="${index}" data-src="${img}">
          <img src="${img}" alt="Thumbnail ${index + 1}" loading="lazy">
        </div>
      `;
    });

    // 18-Point Specifications Schema for Vehicle / General Listings
    const vehicleSpecsSchema = {
      brand: listing.specs?.brand || (listing.title ? listing.title.split(' ')[1] : 'Brand'),
      model: listing.specs?.model || (listing.title ? listing.title.split(' ')[2] : 'Model'),
      variant: listing.specs?.variant || 'SX (O) Turbo DCT',
      manufacturingYear: listing.specs?.year || listing.specs?.manufacturingYear || '2022',
      registrationYear: listing.specs?.registrationYear || '2022',
      fuelType: listing.specs?.fuel || listing.specs?.fuelType || 'Petrol',
      transmission: listing.specs?.transmission || 'Automatic (DCT)',
      kmDriven: listing.specs?.kmDriven || '24,500 km',
      owners: listing.specs?.owners || '1st Owner',
      color: listing.specs?.color || 'Polar White',
      engineCapacity: listing.specs?.engineCapacity || '1353 cc',
      mileage: listing.specs?.mileage || '16.8 kmpl',
      seatingCapacity: listing.specs?.seatingCapacity || '5 Seater',
      bodyType: listing.specs?.bodyType || 'SUV',
      insuranceValidity: listing.specs?.insuranceValidity || 'Valid till Dec 2026',
      registrationNumber: listing.specs?.registrationNumber || 'KA-01-MJ-XXXX',
      serviceHistory: listing.specs?.serviceHistory || 'Full Authorized Service History',
      rto: listing.specs?.rto || 'KA-01 (Bengaluru Central)'
    };

    const specMetaConfig = {
      brand: { label: 'Brand', icon: 'fa-solid fa-car', isKey: true },
      model: { label: 'Model', icon: 'fa-solid fa-car-side', isKey: true },
      variant: { label: 'Variant', icon: 'fa-solid fa-tag' },
      manufacturingYear: { label: 'Mfg Year', icon: 'fa-solid fa-calendar', isKey: true },
      registrationYear: { label: 'Reg Year', icon: 'fa-solid fa-calendar-check' },
      fuelType: { label: 'Fuel Type', icon: 'fa-solid fa-gas-pump', isKey: true },
      transmission: { label: 'Transmission', icon: 'fa-solid fa-gears', isKey: true },
      kmDriven: { label: 'KM Driven', icon: 'fa-solid fa-gauge-high', isKey: true },
      owners: { label: 'No. of Owners', icon: 'fa-solid fa-user-check', isKey: true },
      color: { label: 'Color', icon: 'fa-solid fa-palette' },
      engineCapacity: { label: 'Engine', icon: 'fa-solid fa-microchip' },
      mileage: { label: 'Mileage', icon: 'fa-solid fa-road' },
      seatingCapacity: { label: 'Seating', icon: 'fa-solid fa-chair' },
      bodyType: { label: 'Body Type', icon: 'fa-solid fa-car-rear' },
      insuranceValidity: { label: 'Insurance', icon: 'fa-solid fa-file-shield' },
      registrationNumber: { label: 'Reg Number', icon: 'fa-solid fa-id-card' },
      serviceHistory: { label: 'Service Record', icon: 'fa-solid fa-wrench' },
      rto: { label: 'RTO Office', icon: 'fa-solid fa-map-location-dot' }
    };

    // Build Specifications Highlight Row
    const highlightRowHtml = `
      <div class="specs-highlight-row">
        <div class="specs-highlight-pill">
          <div class="specs-highlight-icon"><i class="fa-solid fa-gas-pump"></i></div>
          <div class="specs-highlight-meta">
            <span class="specs-highlight-label">Fuel</span>
            <span class="specs-highlight-val">${vehicleSpecsSchema.fuelType}</span>
          </div>
        </div>
        <div class="specs-highlight-pill">
          <div class="specs-highlight-icon"><i class="fa-solid fa-gears"></i></div>
          <div class="specs-highlight-meta">
            <span class="specs-highlight-label">Transmission</span>
            <span class="specs-highlight-val">${vehicleSpecsSchema.transmission}</span>
          </div>
        </div>
        <div class="specs-highlight-pill">
          <div class="specs-highlight-icon"><i class="fa-solid fa-gauge-high"></i></div>
          <div class="specs-highlight-meta">
            <span class="specs-highlight-label">KM Driven</span>
            <span class="specs-highlight-val">${vehicleSpecsSchema.kmDriven}</span>
          </div>
        </div>
        <div class="specs-highlight-pill">
          <div class="specs-highlight-icon"><i class="fa-solid fa-calendar"></i></div>
          <div class="specs-highlight-meta">
            <span class="specs-highlight-label">Year</span>
            <span class="specs-highlight-val">${vehicleSpecsSchema.manufacturingYear}</span>
          </div>
        </div>
        <div class="specs-highlight-pill">
          <div class="specs-highlight-icon"><i class="fa-solid fa-user-check"></i></div>
          <div class="specs-highlight-meta">
            <span class="specs-highlight-label">Owners</span>
            <span class="specs-highlight-val">${vehicleSpecsSchema.owners}</span>
          </div>
        </div>
      </div>
    `;

    // Build 18-Point Specs Cards Grid with View More / View Less
    const SPECS_INITIAL_VISIBLE = 8;
    const allSpecEntries = Object.entries(specMetaConfig);
    const totalSpecs = allSpecEntries.length;

    let visibleCardsHtml = '';
    let hiddenCardsHtml = '';

    allSpecEntries.forEach(([key, meta], idx) => {
      const val = vehicleSpecsSchema[key] || 'N/A';
      const isKeyHighlight = meta.isKey ? 'highlight-spec' : '';
      const cardHtml = `
        <div class="spec-card-item ${isKeyHighlight}">
          <div class="spec-icon-box">
            <i class="${meta.icon}"></i>
          </div>
          <div class="spec-card-body">
            <span class="spec-card-label">${meta.label}</span>
            <span class="spec-card-val">${val}</span>
          </div>
        </div>
      `;
      if (idx < SPECS_INITIAL_VISIBLE) {
        visibleCardsHtml += cardHtml;
      } else {
        hiddenCardsHtml += cardHtml;
      }
    });

    const hiddenSection = hiddenCardsHtml ? `
      <div id="specs-extra-cards" style="display:none; grid-column: 1 / -1; display:none;">
        <div class="specs-card-grid" style="margin-top:0; padding-top:0; border-top: none;">
          ${hiddenCardsHtml}
        </div>
      </div>
    ` : '';

    const viewMoreBtn = (totalSpecs > SPECS_INITIAL_VISIBLE) ? `
      <div style="text-align:center; margin-top: 1.25rem;">
        <button id="specs-view-more-btn" onclick="(function(){
          var extra = document.getElementById('specs-extra-cards');
          var btn = document.getElementById('specs-view-more-btn');
          var icon = btn.querySelector('i');
          var isExpanded = extra.style.display !== 'none' && extra.style.display !== '';
          if(isExpanded){
            extra.style.maxHeight = extra.scrollHeight + 'px';
            requestAnimationFrame(function(){
              extra.style.transition = 'max-height 0.4s ease, opacity 0.3s ease';
              extra.style.maxHeight = '0';
              extra.style.opacity = '0';
              setTimeout(function(){ extra.style.display = 'none'; }, 400);
            });
            btn.innerHTML = '<i class=\\'fa-solid fa-chevron-down\\'></i> View More Specs <span style=\\'background:var(--color-saffron-subtle);color:var(--color-saffron);font-size:0.72rem;font-weight:800;padding:0.15rem 0.5rem;border-radius:999px;margin-left:0.4rem;\\'>${totalSpecs - SPECS_INITIAL_VISIBLE} more</span>';
            btn.style.background = 'var(--bg-surface)';
            btn.style.color = 'var(--color-saffron)';
            btn.style.borderColor = 'var(--color-saffron)';
          } else {
            extra.style.display = 'block';
            extra.style.maxHeight = '0';
            extra.style.opacity = '0';
            extra.style.overflow = 'hidden';
            requestAnimationFrame(function(){
              extra.style.transition = 'max-height 0.45s ease, opacity 0.3s ease';
              extra.style.maxHeight = extra.scrollHeight + 600 + 'px';
              extra.style.opacity = '1';
            });
            btn.innerHTML = '<i class=\\'fa-solid fa-chevron-up\\'></i> View Less';
            btn.style.background = 'var(--color-saffron)';
            btn.style.color = '#ffffff';
            btn.style.borderColor = 'var(--color-saffron)';
          }
        })()" style="
          display: inline-flex;
          align-items: center;
          gap: 0.55rem;
          padding: 0.65rem 1.75rem;
          background: var(--bg-surface);
          color: var(--color-saffron);
          border: 2px solid var(--color-saffron);
          border-radius: var(--border-radius-pill);
          font-size: 0.88rem;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
          box-shadow: 0 3px 12px rgba(255,103,31,0.15);
          letter-spacing: 0.3px;
        " onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 20px rgba(255,103,31,0.25)'" onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 3px 12px rgba(255,103,31,0.15)'">
          <i class="fa-solid fa-chevron-down"></i>
          View More Specs
          <span style="background:var(--color-saffron-subtle);color:var(--color-saffron);font-size:0.72rem;font-weight:800;padding:0.15rem 0.5rem;border-radius:999px;margin-left:0.4rem;">${totalSpecs - SPECS_INITIAL_VISIBLE} more</span>
        </button>
      </div>
    ` : '';

    const specCardsHtml = `
      <div class="specs-card-grid">
        ${visibleCardsHtml}
      </div>
      ${hiddenSection}
      ${viewMoreBtn}
    `;

    // Full Details HTML Layout
    container.innerHTML = `
      ${breadcrumbsHtml}
      <div class="details-layout">
        <!-- Left Column: Gallery & Details -->
        <div class="details-left">
          <!-- Gallery -->
          <div class="gallery-container">
            <!-- Trust / Status Badges Strip -->
            <div class="gallery-trust-badges">
              <span class="badge-pill badge-pill-verified"><i class="fa-solid fa-circle-check"></i> Verified Ad</span>
              <span class="badge-pill badge-pill-owner"><i class="fa-solid fa-user-shield"></i> Single Owner</span>
              <span class="badge-pill badge-pill-maintained"><i class="fa-solid fa-star"></i> Well Maintained</span>
            </div>

            <!-- Image Viewer -->
            <div class="main-image-view" id="main-gallery-view">
              <img id="active-gallery-img" src="${images[0]}" alt="${listing.title}">
              
              <!-- Left / Right Navigation Arrows -->
              <button class="gallery-nav-btn gallery-nav-prev" id="btn-prev-img" aria-label="Previous Image">
                <i class="fa-solid fa-chevron-left"></i>
              </button>
              <button class="gallery-nav-btn gallery-nav-next" id="btn-next-img" aria-label="Next Image">
                <i class="fa-solid fa-chevron-right"></i>
              </button>

              <!-- Counter Overlay Tag -->
              <div class="gallery-counter-tag">
                <i class="fa-solid fa-camera"></i> <span id="gallery-current-idx">1</span> / ${images.length}
              </div>

              <!-- Fullscreen Button -->
              <button class="gallery-fullscreen-btn" id="btn-fullscreen-img">
                <i class="fa-solid fa-expand"></i> Fullscreen
              </button>
            </div>

            <!-- Thumbnails Strip -->
            ${images.length > 1 ? `<div class="thumbnails-strip" id="thumbnails-strip">${thumbsHtml}</div>` : ''}
          </div>

          <!-- Description Block -->
          <div style="background: var(--bg-surface); border: 1.5px solid var(--border-color); border-radius: var(--border-radius-lg); padding: 1.75rem; margin-top: 1.5rem; box-shadow: var(--shadow-sm);">
            <h3 style="margin-bottom: 0.75rem; font-size: 1.25rem;">Description</h3>
            <p style="white-space: pre-line; line-height: 1.6; color: var(--text-primary); font-size: 0.95rem;">${listing.description || 'No detailed description provided.'}</p>
            
            <h3 style="margin-top: 2rem; margin-bottom: 1rem; font-size: 1.25rem; display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-sliders" style="color: var(--color-saffron);"></i> Key Specifications
            </h3>

            ${highlightRowHtml}
            ${specCardsHtml}
          </div>

          <!-- Location & Map Mockup -->
          <div style="background: var(--bg-surface); border: 1.5px solid var(--border-color); border-radius: var(--border-radius-lg); padding: 1.75rem; margin-top: 1.5rem; box-shadow: var(--shadow-sm);">
            <h3 style="margin-bottom: 0.75rem; font-size: 1.25rem; display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-location-dot" style="color: var(--color-green);"></i> Location & Radius Map
            </h3>
            <p style="font-weight: 600; color: var(--text-primary); margin-bottom: 0.85rem;">${listing.locality ? listing.locality + ', ' : ''}${listing.location}</p>
            <div style="width: 100%; height: 180px; background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%); border-radius: 14px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.5rem; color: var(--text-secondary); border: 1.5px dashed var(--border-color);">
              <i class="fa-solid fa-map-location-dot" style="font-size: 2.2rem; color: var(--color-saffron);"></i>
              <span style="font-weight: 700; font-size: 0.9rem;">Verified Location Pin (${listing.location})</span>
            </div>
          </div>
        </div>

        <!-- Right Column: Price & Seller Card -->
        <div class="details-right" style="display: flex; flex-direction: column; gap: 1.25rem;">
          <!-- Price Card -->
          <div class="seller-box" style="border-radius: var(--border-radius-lg); box-shadow: var(--shadow-sm);">
            <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 0.5rem;">
              <div style="font-size: 2.1rem; font-weight: 900; color: var(--color-saffron-dark);">${listing.formattedPrice}</div>
              <div style="display: flex; gap: 0.5rem;">
                <button class="card-heart-btn ${isSaved ? 'active' : ''}" style="position: static;" onclick="window.Wishlist.toggle('${listing.id}')">
                  <i class="${isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
                </button>
                <button class="card-heart-btn" style="position: static;" onclick='window.Modal.openShareModal(${JSON.stringify(listing)})'>
                  <i class="fa-solid fa-share-nodes"></i>
                </button>
              </div>
            </div>
            <h1 style="font-size: 1.25rem; font-weight: 800; margin-bottom: 0.75rem; line-height: 1.35;">${listing.title}</h1>
            <div style="font-size: 0.8rem; color: var(--text-muted); display: flex; justify-content: space-between; border-top: 1px solid var(--border-color-light); padding-top: 0.6rem;">
              <span><i class="fa-solid fa-location-pin" style="color: var(--color-green);"></i> ${listing.locality || listing.location}</span>
              <span><i class="fa-regular fa-clock"></i> ${listing.postedDate}</span>
            </div>
          </div>

          <!-- Seller Profile Card -->
          <div class="seller-box" style="border-radius: var(--border-radius-lg); box-shadow: var(--shadow-sm);">
            <h4 style="margin-bottom: 1rem; font-size: 1.05rem; font-weight: 800;">Seller Information</h4>
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.25rem;">
              <img src="${listing.seller?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}" class="seller-avatar-lg" alt="Seller">
              <div>
                <div style="font-weight: 800; font-size: 1.05rem;">${listing.seller?.name || 'OLX Member'}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">Member since ${listing.seller?.memberSince || '2023'}</div>
                ${listing.seller?.verified ? '<div style="color: var(--color-green); font-size: 0.82rem; font-weight: 700; margin-top: 2px;"><i class="fa-solid fa-circle-check"></i> Verified Seller Profile</div>' : ''}
              </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
              <button class="btn btn-primary btn-block btn-lg" onclick='window.Modal.openChatModal(${JSON.stringify(listing)})'>
                <i class="fa-solid fa-comments"></i> Chat with Seller
              </button>
              <button class="btn btn-secondary btn-block btn-lg" onclick='window.Modal.openContactModal(${JSON.stringify(listing)})'>
                <i class="fa-solid fa-phone"></i> Show Contact Number
              </button>
            </div>
          </div>

          <!-- Safety Tips -->
          <div class="seller-box" style="background: var(--color-saffron-subtle); border: 1.5px solid #ffd8c2; border-radius: var(--border-radius-lg);">
            <h4 style="color: var(--color-saffron-dark); font-size: 0.95rem; margin-bottom: 0.5rem; font-weight: 800;">
              <i class="fa-solid fa-shield-halved"></i> Safety Warning
            </h4>
            <ul style="font-size: 0.82rem; color: var(--text-secondary); display: flex; flex-direction: column; gap: 0.35rem;">
              <li>• Meet seller at a safe public location</li>
              <li>• Check item before making any payment</li>
              <li>• Beware of unrealistically low prices</li>
            </ul>
            <button class="btn btn-sm" style="color: var(--color-danger); padding: 0.5rem 0 0 0; font-size: 0.8rem; font-weight: 800;" onclick='window.Modal.openReportModal(${JSON.stringify(listing)})'>
              <i class="fa-solid fa-flag"></i> Report this ad
            </button>
          </div>
        </div>
      </div>

      <!-- Related Listings -->
      <div style="margin-top: 3rem;">
        <h2 style="margin-bottom: 1.25rem;">Related Listings in ${category.name}</h2>
        <div class="grid-listings" id="related-listings-grid"></div>
      </div>
    `;

    // Interactive Gallery State & Controller
    let currentImgIdx = 0;
    const activeImg = document.getElementById('active-gallery-img');
    const idxSpan = document.getElementById('gallery-current-idx');

    const updateGalleryView = (newIdx) => {
      if (newIdx < 0) newIdx = images.length - 1;
      if (newIdx >= images.length) newIdx = 0;
      currentImgIdx = newIdx;

      if (activeImg) {
        activeImg.style.opacity = '0.3';
        setTimeout(() => {
          activeImg.src = images[currentImgIdx];
          activeImg.style.opacity = '1';
        }, 120);
      }

      if (idxSpan) {
        idxSpan.textContent = currentImgIdx + 1;
      }

      // Update thumbnail active states
      document.querySelectorAll('.thumb-item').forEach((t, i) => {
        if (i === currentImgIdx) {
          t.classList.add('active');
          t.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        } else {
          t.classList.remove('active');
        }
      });
    };

    // Bind Gallery Controls
    const prevBtn = document.getElementById('btn-prev-img');
    const nextBtn = document.getElementById('btn-next-img');
    const fsBtn = document.getElementById('btn-fullscreen-img');

    if (prevBtn) prevBtn.addEventListener('click', () => updateGalleryView(currentImgIdx - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => updateGalleryView(currentImgIdx + 1));
    if (fsBtn) {
      fsBtn.addEventListener('click', () => {
        if (window.Modal && window.Modal.openLightbox) {
          window.Modal.openLightbox(images[currentImgIdx]);
        }
      });
    }

    // Bind Gallery Thumbnail Clicks
    document.querySelectorAll('.thumb-item').forEach(thumb => {
      thumb.addEventListener('click', () => {
        const idx = parseInt(thumb.getAttribute('data-index'), 10);
        updateGalleryView(idx);
      });
    });

    // Touch Swipe Support for Gallery
    const galleryViewEl = document.getElementById('main-gallery-view');
    if (galleryViewEl) {
      let touchStartX = 0;
      let touchEndX = 0;
      galleryViewEl.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
      }, { passive: true });
      galleryViewEl.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        if (touchStartX - touchEndX > 40) updateGalleryView(currentImgIdx + 1); // Swipe left -> Next
        if (touchEndX - touchStartX > 40) updateGalleryView(currentImgIdx - 1); // Swipe right -> Prev
      }, { passive: true });
    }

    // Render Related Listings
    const relatedGrid = document.getElementById('related-listings-grid');
    if (relatedGrid) {
      const allListings = window.DataStore.getListings();
      const related = allListings.filter(item => item.category === listing.category && item.id !== listing.id).slice(0, 4);
      if (related.length > 0) {
        let relHtml = '';
        related.forEach(item => {
          relHtml += this.createCardHtml(item);
        });
        relatedGrid.innerHTML = relHtml;
      } else {
        relatedGrid.innerHTML = `<p style="color: var(--text-muted); grid-column: 1 / -1;">No other active listings found in this category.</p>`;
      }
    }
  },

  addRecentlyViewed(id) {
    try {
      let recent = JSON.parse(localStorage.getItem('olx_recently_viewed')) || [];
      recent = recent.filter(item => item !== id);
      recent.unshift(id);
      recent = recent.slice(0, 6);
      localStorage.setItem('olx_recently_viewed', JSON.stringify(recent));
    } catch (e) {}
  },

  renderRecentlyViewed(containerId = 'recently-viewed-grid') {
    const container = document.getElementById(containerId);
    if (!container) return;

    try {
      const recentIds = JSON.parse(localStorage.getItem('olx_recently_viewed')) || [];
      if (recentIds.length === 0) {
        const section = container.closest('.recently-viewed-section');
        if (section) section.style.display = 'none';
        return;
      }

      const allListings = window.DataStore.getListings();
      const items = recentIds.map(id => allListings.find(l => l.id === id)).filter(Boolean);

      if (items.length === 0) {
        const section = container.closest('.recently-viewed-section');
        if (section) section.style.display = 'none';
        return;
      }

      let html = '';
      items.forEach(item => {
        html += this.createCardHtml(item);
      });
      container.innerHTML = html;
    } catch (e) {}
  }
};

window.Listings = Listings;
