import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/categories/:slug" element={<div>Category Page</div>} />
          <Route path="/item/:id" element={<div>Listing Detail Page</div>} />
          <Route path="/sell" element={<div>Sell Page</div>} />
          <Route path="/wishlist" element={<div>Wishlist Page</div>} />
          <Route path="/profile" element={<div>Profile Page</div>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
