import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { CATEGORIES_DATA } from '../../data';

export default function CategoryNavBar() {
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const wrapperRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsMegaMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <nav className="category-nav-bar" aria-label="Marketplace Categories">
      <div className="container category-nav-container">
        <div className={`all-cats-mega-wrapper ${isMegaMenuOpen ? 'active' : ''}`} id="all-cats-mega-wrapper" ref={wrapperRef}>
          <button 
            type="button" 
            className="all-cats-btn" 
            onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
            aria-expanded={isMegaMenuOpen}
          >
            <span className="all-cats-label">ALL CATEGORIES</span>
            <i className="fa-solid fa-chevron-down all-cats-chevron"></i>
          </button>
          
          <div className="mega-menu-dropdown" id="mega-menu-dropdown" role="menu">
            <div className="mega-menu-top-bar">
              <div className="mega-menu-title">
                <i className="fa-solid fa-layer-group"></i> Browse All {CATEGORIES_DATA.length} Categories & Hubs
              </div>
              <span className="mega-menu-count">{CATEGORIES_DATA.length} Categories</span>
            </div>
            <div className="mega-menu-grid">
              {CATEGORIES_DATA.map(cat => (
                <div key={cat.id} className="mega-cat-card">
                  <Link to={`/categories/${cat.slug}`} className="mega-cat-header" title={cat.name} onClick={() => setIsMegaMenuOpen(false)}>
                    <div className="mega-cat-icon">
                      <i className={cat.icon}></i>
                    </div>
                    <span className="mega-cat-name">{cat.name}</span>
                  </Link>
                  <ul className="mega-subcat-list">
                    {cat.subcategories?.map(sub => (
                      <li key={sub.id} className="mega-subcat-item">
                        <Link to={`/categories/${cat.slug}?sub=${sub.id}`} className="mega-subcat-link" onClick={() => setIsMegaMenuOpen(false)}>
                          <i className={sub.icon || 'fa-solid fa-angle-right'}></i>
                          <span>{sub.name}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
