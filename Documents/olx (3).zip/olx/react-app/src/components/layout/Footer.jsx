import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <div className="header-logo" style={{ color: '#fff', marginBottom: '0.75rem' }}>
              <i className="fa-solid fa-cube" style={{ color: 'var(--color-saffron)' }}></i> OLX<span style={{ color: 'var(--color-green-light)' }}>.</span>
            </div>
            <p style={{ color: '#90a4ae', fontSize: '0.85rem', lineHeight: 1.6, marginBottom: '1rem' }}>
              The leading next-generation classifieds marketplace connecting millions of buyers and sellers across Real Estate, Vehicles, Jobs, Electronics, and Services.
            </p>
            <div style={{ display: 'flex', gap: '0.75rem', fontSize: '1.25rem' }}>
              <a href="#" style={{ color: '#90a4ae' }}><i className="fa-brands fa-facebook"></i></a>
              <a href="#" style={{ color: '#90a4ae' }}><i className="fa-brands fa-instagram"></i></a>
              <a href="#" style={{ color: '#90a4ae' }}><i className="fa-brands fa-x-twitter"></i></a>
              <a href="#" style={{ color: '#90a4ae' }}><i className="fa-brands fa-youtube"></i></a>
            </div>
          </div>
          <div className="footer-col">
            <h4>Popular Categories</h4>
            <ul>
              <li><Link to="/categories/real-estate">Real Estate & Plots</Link></li>
              <li><Link to="/categories/vehicles">Cars & Motorbikes</Link></li>
              <li><Link to="/categories/electronics">Mobile Phones & Laptops</Link></li>
              <li><Link to="/categories/jobs">Remote & Tech Jobs</Link></li>
              <li><Link to="/categories/home-furniture">Home & Furniture</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>More Categories</h4>
            <ul>
              <li><Link to="/categories/fashion">Fashion & Lifestyle</Link></li>
              <li><Link to="/categories/education">Courses & Tutors</Link></li>
              <li><Link to="/categories/services">Professional Services</Link></li>
              <li><Link to="/categories/tourism">Tourism & Hotels</Link></li>
              <li><Link to="/categories/agriculture">Agriculture & Tractors</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Trending Locations</h4>
            <ul>
              <li><Link to="/?loc=Mumbai">Mumbai</Link></li>
              <li><Link to="/?loc=Delhi">Delhi NCR</Link></li>
              <li><Link to="/?loc=Bengaluru">Bengaluru</Link></li>
              <li><Link to="/?loc=Hyderabad">Hyderabad</Link></li>
              <li><Link to="/?loc=Pune">Pune</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>OLX Marketplace App</h4>
            <p style={{ color: '#90a4ae', fontSize: '0.85rem', marginBottom: '0.75rem' }}>
              Buy & sell on the go with real-time push alerts and lightning-fast search.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <a href="#" className="btn btn-sm btn-secondary" style={{ color: '#fff', borderColor: 'rgba(255,255,255,0.3)' }}><i className="fa-brands fa-apple"></i> App Store</a>
              <a href="#" className="btn btn-sm btn-secondary" style={{ color: '#fff', borderColor: 'rgba(255,255,255,0.3)' }}><i className="fa-brands fa-google-play"></i> Google Play</a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div>
            <span>Free Classifieds in India. &copy; 2026 OLX Marketplace Clone. All rights reserved.</span>
          </div>
          <div style={{ display: 'flex', gap: '1.5rem' }}>
            <a href="#" style={{ color: '#90a4ae' }}>Help & Support</a>
            <a href="#" style={{ color: '#90a4ae' }}>Terms of Use</a>
            <a href="#" style={{ color: '#90a4ae' }}>Privacy Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
