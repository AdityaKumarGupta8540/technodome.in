import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Header({ onMenuClick }) {
  const [isLocationOpen, setIsLocationOpen] = useState(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="container header-container">
        {/* Mobile Hamburger */}
        <button className="mobile-nav-toggle" id="btn-mobile-menu-toggle" aria-label="Open Navigation Menu" onClick={onMenuClick}>
          <i className="fa-solid fa-bars"></i>
        </button>

        {/* Logo */}
        <Link to="/" className="header-logo" title="OLX Marketplace">
          <i className="fa-solid fa-cube"></i> OLX<span>.</span>
        </Link>

        {/* Location Selector */}
        <div className="location-selector" onClick={() => setIsLocationOpen(!isLocationOpen)}>
          <button className="location-btn" id="header-location-btn">
            <span className="truncate"><i className="fa-solid fa-location-dot"></i> <span id="selected-location-text">All India</span></span>
            <i className="fa-solid fa-chevron-down" style={{ fontSize: '0.75rem' }}></i>
          </button>
          <div className={`location-dropdown ${isLocationOpen ? 'active' : ''}`} id="header-location-dropdown">
            <div className="location-option" data-loc="All India">
              <i className="fa-solid fa-earth-asia"></i> <strong>All India</strong>
            </div>
            {['Mumbai, Maharashtra', 'Delhi NCR, Delhi', 'Bengaluru, Karnataka', 'Hyderabad, Telangana', 'Chennai, Tamil Nadu'].map(loc => (
              <div key={loc} className="location-option" data-loc={loc}>
                <i className="fa-solid fa-location-dot"></i> {loc}
              </div>
            ))}
          </div>
        </div>

        {/* Global Search */}
        <div className="global-search">
          <div className="search-input-wrapper">
            <div className="search-cat-selector" id="search-cat-selector" onClick={() => setIsCategoryOpen(!isCategoryOpen)}>
              <button type="button" className="search-cat-btn" id="search-cat-btn" title="Filter by category">
                <i className="fa-solid fa-layer-group search-cat-btn-icon"></i>
                <span className="search-cat-text truncate" id="search-cat-btn-text">All Categories</span>
                <i className="fa-solid fa-chevron-down search-cat-chevron"></i>
              </button>
              <div className={`search-cat-dropdown ${isCategoryOpen ? 'active' : ''}`} id="search-cat-dropdown">
                <div className="search-cat-item-all active"><i className="fa-solid fa-layer-group"></i> <strong>All Categories</strong></div>
              </div>
            </div>

            <input type="text" id="global-search-input" className="search-input" placeholder="Find Cars, Mobile Phones, Real Estate, Jobs and more..." autoComplete="off" />
            <button type="button" className="search-btn" id="global-search-btn" aria-label="Search">
              <i className="fa-solid fa-magnifying-glass"></i>
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="header-actions">
          <Link to="/wishlist" className="wishlist-link" title="My Wishlist">
            <i className="fa-regular fa-heart"></i>
          </Link>

          <div id="header-auth-container">
            <button className="auth-btn">Login</button>
          </div>

          <Link to="/sell" className="btn-sell">
            <i className="fa-solid fa-plus"></i> SELL
          </Link>
        </div>
      </div>
    </header>
  );
}
