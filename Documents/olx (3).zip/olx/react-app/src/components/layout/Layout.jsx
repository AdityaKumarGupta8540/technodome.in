import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import CategoryNavBar from './CategoryNavBar';
import Footer from './Footer';
import MobileDrawer from './MobileDrawer';
import MobileBottomNav from './MobileBottomNav';

export default function Layout() {
  // Pass state to Header so it can trigger the drawer, or use a global store later.
  // For now, we will add a small context or prop to Header
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  return (
    <>
      <Header onMenuClick={() => setIsDrawerOpen(true)} />
      <CategoryNavBar />
      <main className="main-content">
        <Outlet />
      </main>
      <Footer />
      <MobileDrawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} />
      <MobileBottomNav />
    </>
  );
}
