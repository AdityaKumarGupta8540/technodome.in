import React from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function MobileBottomNav() {
  const location = useLocation();
  const path = location.pathname;

  return (
    <nav id="mobile-bottom-nav-root" className="mobile-bottom-nav">
      <Link to="/" className={mobile-bottom-nav-item }>
        <i className="fa-solid fa-house"></i>
        <span>Home</span>
      </Link>
      <Link to="/wishlist" className={mobile-bottom-nav-item }>
        <i className="fa-solid fa-heart"></i>
        <span>Wishlist</span>
      </Link>
      <Link to="/sell" className="mobile-bottom-nav-item mobile-sell-btn">
        <div className="sell-circle">
          <i className="fa-solid fa-plus"></i>
        </div>
        <span>SELL</span>
      </Link>
      <a href="javascript:void(0)" className="mobile-bottom-nav-item">
        <i className="fa-solid fa-comments"></i>
        <span>Chat</span>
      </a>
      <Link to="/profile" className={mobile-bottom-nav-item }>
        <i className="fa-solid fa-user"></i>
        <span>Profile</span>
      </Link>
    </nav>
  );
}
