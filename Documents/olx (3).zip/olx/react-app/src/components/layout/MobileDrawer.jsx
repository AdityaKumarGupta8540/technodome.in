import React from 'react';
import { Link } from 'react-router-dom';
import { CATEGORIES_DATA } from '../../data';

export default function MobileDrawer({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div id="mobile-drawer-root">
      <div className={`mobile-drawer-backdrop ${isOpen ? 'active' : ''}`} id="mobile-drawer-backdrop" onClick={onClose}></div>
      <aside className={`mobile-drawer ${isOpen ? 'active' : ''}`} id="mobile-drawer-panel">
        <div className="mobile-drawer-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 800, fontSize: '1.25rem' }}>
            <i className="fa-solid fa-cube"></i> OLX Menu
          </div>
          <button id="btn-close-drawer" style={{ color: '#fff', fontSize: '1.5rem' }} onClick={onClose}>&times;</button>
        </div>
        <div className="mobile-drawer-body">
          <div style={{ padding: '0.75rem 1.25rem', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Marketplace Categories
          </div>
          {CATEGORIES_DATA.map(c => (
            <Link key={c.id} to={`/categories/${c.slug}`} className="mobile-drawer-link" onClick={onClose}>
              <i className={c.icon}></i> {c.name}
            </Link>
          ))}
          <div style={{ padding: '0.75rem 1.25rem', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', marginTop: '1rem' }}>
            My Account
          </div>
          <Link to="/profile" className="mobile-drawer-link" onClick={onClose}><i className="fa-solid fa-user"></i> My Profile & Ads</Link>
          <Link to="/wishlist" className="mobile-drawer-link" onClick={onClose}><i className="fa-solid fa-heart"></i> Saved Favorites</Link>
          <Link to="/sell" className="mobile-drawer-link" onClick={onClose}><i className="fa-solid fa-plus-circle"></i> Post New Ad</Link>
        </div>
      </aside>
    </div>
  );
}
