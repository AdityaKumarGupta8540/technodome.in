import React from 'react';
import { Link } from 'react-router-dom';

export default function DealCard({ deal, isSaved, onToggleWishlist }) {
  const detailUrl = `/item/${deal.id}`;
  const mainImg = deal.images && deal.images.length > 0 
    ? deal.images[0] 
    : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';
  const discount = deal.discountPercent ? `${deal.discountPercent}% OFF` : (deal.dealBadge || 'HOT DEAL');
  const originalPriceFormatted = deal.formattedOriginalPrice || (deal.originalPrice ? `₹ ${Number(deal.originalPrice).toLocaleString('en-IN')}` : '');
  const savingsFormatted = deal.originalPrice && deal.price ? `Save ₹ ${(deal.originalPrice - deal.price).toLocaleString('en-IN')}` : '';
  const claimedPercent = deal.claimedPercent || 78;

  return (
    <div className="deal-card">
      <div className="deal-card-media">
        <Link to={detailUrl} className="deal-card-img-link" tabIndex="-1">
          <img src={mainImg} alt={deal.title} className="deal-card-img" loading="lazy" />
        </Link>
        <span className="deal-badge-discount">
          <i className="fa-solid fa-fire"></i> {discount}
        </span>
        <button 
          className={`card-heart-btn ${isSaved ? 'active' : ''}`} 
          title="Save to Wishlist" 
          onClick={() => onToggleWishlist(deal.id)}
        >
          <i className={isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}></i>
        </button>
        <div className="deal-tag-ends">
          <i className="fa-regular fa-clock"></i> Limited Time
        </div>
      </div>

      <div className="deal-card-body">
        <div className="deal-price-row">
          <div className="deal-current-price">{deal.formattedPrice}</div>
          {originalPriceFormatted && <div className="deal-original-price">{originalPriceFormatted}</div>}
        </div>
        {savingsFormatted && <div className="deal-save-badge"><i className="fa-solid fa-tag"></i> {savingsFormatted}</div>}

        <h3 className="deal-card-title">
          <Link to={detailUrl} title={deal.title}>{deal.title}</Link>
        </h3>

        <div className="deal-meta-info">
          <span className="truncate"><i className="fa-solid fa-location-dot"></i> {deal.locality || deal.location}</span>
          <span className="deal-cat-tag"><i className="fa-solid fa-layer-group"></i> {deal.subcategory || deal.category}</span>
        </div>

        <div className="deal-progress-container">
          <div className="deal-progress-bar">
            <div className="deal-progress-fill" style={{ width: `${claimedPercent}%` }}></div>
          </div>
          <div className="deal-progress-label">
            <span><i className="fa-solid fa-bolt" style={{ color: '#f59e0b' }}></i> {claimedPercent}% Claimed</span>
            <span className="deal-hurry-text">Selling Fast</span>
          </div>
        </div>

        <Link to={detailUrl} className="deal-cta-btn">
          <span>View Deal</span>
          <i className="fa-solid fa-arrow-right"></i>
        </Link>
      </div>
    </div>
  );
}
