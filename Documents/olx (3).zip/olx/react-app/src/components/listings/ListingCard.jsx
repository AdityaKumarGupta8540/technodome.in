import React from 'react';
import { Link } from 'react-router-dom';

export default function ListingCard({ listing, isSaved, onToggleWishlist }) {
  const detailUrl = `/item/${listing.id}`;
  const mainImg = listing.images && listing.images.length > 0 
    ? listing.images[0] 
    : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';

  return (
    <div className={`listing-card ${listing.featured ? 'featured-card' : ''}`}>
      <div className="card-img-wrap">
        <Link to={detailUrl} className="card-img-link" tabIndex="-1">
          <img src={mainImg} alt={listing.title} className="card-img" loading="lazy" />
        </Link>
        {listing.featured && (
          <>
            <div className="card-badge-featured">
              <i className="fa-solid fa-bolt"></i> Featured
            </div>
            <div className="card-badge-verified">
              <i className="fa-solid fa-circle-check"></i> Verified
            </div>
          </>
        )}
        <button 
          className={`card-heart-btn ${isSaved ? 'active' : ''}`} 
          title="Save to Wishlist" 
          onClick={() => onToggleWishlist(listing.id)}
        >
          <i className={isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}></i>
        </button>
      </div>
      <div className="card-body">
        <div className="card-price-row">
          <div className="card-price">{listing.formattedPrice}</div>
          {listing.featured && <span className="card-tag-premium"><i className="fa-solid fa-crown"></i> Top Ad</span>}
        </div>
        <h3 className="card-title line-clamp-2">
          <Link to={detailUrl} title={listing.title}>{listing.title}</Link>
        </h3>
        <div className="card-meta-tags">
          {listing.specs && Object.values(listing.specs).slice(0, 2).map((val, i) => (
            <span key={i} className="card-spec-tag">{val}</span>
          ))}
          {(!listing.specs || Object.keys(listing.specs).length === 0) && (
            <span className="card-spec-tag">{listing.subcategory || listing.category}</span>
          )}
        </div>
        <div className="card-footer">
          <span className="truncate"><i className="fa-solid fa-location-dot"></i> {listing.locality || listing.location}</span>
          <span><i className="fa-regular fa-clock" style={{ fontSize: '0.72rem' }}></i> {listing.postedDate}</span>
        </div>
      </div>
    </div>
  );
}
