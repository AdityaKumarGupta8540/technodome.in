import React, { useState, useEffect } from 'react';
import { CATEGORIES_DATA, DataStore, HOT_DEALS_DATA } from '../data';
import ListingCard from '../components/listings/ListingCard';
import DealCard from '../components/listings/DealCard';
import { useWishlistStore } from '../store/wishlistStore';
import { Link } from 'react-router-dom';

export default function HomePage() {
  const [timeLeft, setTimeLeft] = useState({ h: 0, m: 0, s: 0 });
  const wishlistItems = useWishlistStore(state => state.items);
  const toggleWishlist = useWishlistStore(state => state.toggleWishlist);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const target = new Date(now);
      target.setHours(23, 59, 59, 999);
      const diff = Math.max(0, target - now);

      setTimeLeft({
        h: Math.floor((diff / (1000 * 60 * 60)) % 24),
        m: Math.floor((diff / (1000 * 60)) % 60),
        s: Math.floor((diff / 1000) % 60)
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const allListings = DataStore.getListings();
  const featured = allListings.filter(l => l.featured && !l.id.startsWith('deal-')).slice(0, 4);
  const freshListings = allListings.filter(l => !l.id.startsWith('deal-')).slice(0, 8);

  const scrollRef = React.useRef(null);
  const scroll = (direction) => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollRef.current.offsetWidth * 0.75 : scrollRef.current.offsetWidth * 0.75,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="container">
      {/* 1. Categories Carousel */}
      <section className="mb-8" style={{ marginTop: '1.5rem' }}>
        <div className="flex items-center justify-between mb-4">
          <h2>Browse categories</h2>
          <div className="flex gap-2">
            <button className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', borderRadius: '50%' }} onClick={() => scroll('left')}>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', borderRadius: '50%' }} onClick={() => scroll('right')}>
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>
        <div className="categories-carousel-container" style={{ position: 'relative', overflow: 'hidden' }}>
          <div 
            className="flex gap-4" 
            ref={scrollRef}
            style={{ 
              overflowX: 'auto', 
              scrollbarWidth: 'none', 
              msOverflowStyle: 'none', 
              scrollSnapType: 'x mandatory',
              paddingBottom: '1rem' 
            }}
          >
            {CATEGORIES_DATA.map(c => (
              <Link key={c.id} to={/categories/} className="category-card" title={c.name} style={{ flex: '0 0 auto', width: '140px', scrollSnapAlign: 'start' }}>
                <div className="category-img-wrapper">
                  <img src={c.banner} alt={c.name} loading="lazy" className="category-img" />
                  <div className="category-img-overlay"></div>
                  <div className="category-icon-badge"><i className={c.icon}></i></div>
                </div>
                <span className="category-card-name">{c.name}</span>
                <span className="category-card-count">{c.subcategories ? c.subcategories.length + ' Hubs' : 'Explore'} <i className="fa-solid fa-angle-right" style={{ fontSize: '0.65rem' }}></i></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Featured Recommendations */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2>Featured Recommendations</h2>
          <a href="#" className="text-link text-sm text-bold">View all <i className="fa-solid fa-arrow-right"></i></a>
        </div>
        <div className="grid-listings">
          {featured.map(item => (
            <ListingCard 
              key={item.id} 
              listing={item} 
              isSaved={wishlistItems.includes(item.id)}
              onToggleWishlist={toggleWishlist}
            />
          ))}
        </div>
      </section>

      {/* 3. Hot Deals */}
      <section className="mb-8 hot-deals-section">
        <div className="hot-deals-header">
          <div className="flex items-center gap-2">
            <div className="deals-fire-icon"><i className="fa-solid fa-fire-flame-curved"></i></div>
            <h2 className="deals-title">Hot Deals Today</h2>
          </div>
          <div className="deals-countdown">
            <span className="deals-ends-in">Ends in:</span>
            <div className="timer-box">{String(timeLeft.h).padStart(2, '0')}</div><span className="timer-colon">:</span>
            <div className="timer-box">{String(timeLeft.m).padStart(2, '0')}</div><span className="timer-colon">:</span>
            <div className="timer-box">{String(timeLeft.s).padStart(2, '0')}</div>
          </div>
        </div>
        <div className="grid-listings">
          {HOT_DEALS_DATA.map(deal => (
            <DealCard 
              key={deal.id} 
              deal={deal} 
              isSaved={wishlistItems.includes(deal.id)}
              onToggleWishlist={toggleWishlist}
            />
          ))}
        </div>
      </section>

      {/* 4. Fresh Listings */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2>Fresh recommendations</h2>
        </div>
        <div className="grid-listings mb-6">
          {freshListings.map(item => (
            <ListingCard 
              key={item.id} 
              listing={item} 
              isSaved={wishlistItems.includes(item.id)}
              onToggleWishlist={toggleWishlist}
            />
          ))}
        </div>
        <div className="text-center">
          <button className="btn btn-secondary btn-lg" style={{ minWidth: '200px' }}>Load More</button>
        </div>
      </section>
    </div>
  );
}
