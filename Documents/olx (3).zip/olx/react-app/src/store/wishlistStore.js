import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useWishlistStore = create(
  persist(
    (set, get) => ({
      items: [],
      toggleWishlist: (id) => {
        set((state) => {
          const exists = state.items.includes(id);
          if (exists) {
            return { items: state.items.filter(item => item !== id) };
          } else {
            return { items: [...state.items, id] };
          }
        });
      },
      isWishlisted: (id) => get().items.includes(id),
    }),
    {
      name: 'olx_wishlist',
    }
  )
);
