/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        saffron: { DEFAULT: '#FF671F', light: '#FF8545', dark: '#D9530F', subtle: '#FFF4EE', glow: 'rgba(255,103,31,0.25)' },
        green:   { DEFAULT: '#046A38', light: '#16A34A', dark: '#03522B', subtle: '#F0FDF4', glow: 'rgba(4,106,56,0.25)'   },
        chakra:  { DEFAULT: '#06103A', light: '#1E293B', subtle: '#F1F5F9' }
      }
    },
  },
  plugins: [],
}
