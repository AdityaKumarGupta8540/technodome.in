/**
 * OLX Listings Renderer & Single Listing View Module
 * Handles card rendering, details page view, image zoom, and related listings.
 */

const Listings = {
  createCardHtml(listing) {
    const isSaved = window.DataStore.isWishlisted(listing.id);
    const basePath = window.App ? window.App.getBasePath() : './';
    const detailUrl = `${basePath}pages/listing-details.html?id=${listing.id}`;
    const mainImg = listing.images && listing.images.length > 0 
      ? listing.images[0] 
      : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';

    return `
      <div class="listing-card ${listing.featured ? 'featured-card' : ''}" data-listing-id="${listing.id}">
        <div class="card-img-wrap">
          <a href="${detailUrl}">
            <img src="${mainImg}" alt="${listing.title}" class="card-img" loading="lazy">
          </a>
          ${listing.featured ? '<span class="card-badge-featured"><i class="fa-solid fa-bolt"></i> Featured</span>' : ''}
          <button class="card-heart-btn ${isSaved ? 'active' : ''}" data-id="${listing.id}" title="Save to Wishlist" onclick="window.Wishlist.toggle('${listing.id}')">
            <i class="${isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
          </button>
        </div>
        <div class="card-body">
          <div class="card-price">${listing.formattedPrice}</div>
          <h3 class="card-title line-clamp-2">
            <a href="${detailUrl}">${listing.title}</a>
          </h3>
          <div class="card-meta-tags truncate">
            <i class="fa-solid fa-tags" style="color: var(--text-muted); font-size: 0.75rem;"></i>
            <span>${listing.specs ? Object.values(listing.specs).slice(0, 2).join(' • ') : listing.subcategory || listing.category}</span>
          </div>
          <div class="card-footer">
            <span class="truncate"><i class="fa-solid fa-location-dot"></i> ${listing.locality || listing.location}</span>
            <span>${listing.postedDate}</span>
          </div>
        </div>
      </div>
    `;
  },

  renderDetailsPage() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const container = document.getElementById('listing-details-container');
    if (!container) return;

    if (!id) {
      container.innerHTML = `
        <div class="empty-state text-center" style="padding: 4rem 1rem;">
          <h2>No Listing Specified</h2>
          <p>Please select a listing from the marketplace to view details.</p>
          <a href="../index.html" class="btn btn-primary mt-4">Browse Marketplace</a>
        </div>
      `;
      return;
    }

    const listing = window.DataStore.getListingById(id);
    if (!listing) {
      container.innerHTML = `
        <div class="empty-state text-center" style="padding: 4rem 1rem;">
          <h2>Listing Not Found</h2>
          <p>The ad you are looking for might have been sold or removed.</p>
          <a href="../index.html" class="btn btn-primary mt-4">Return Home</a>
        </div>
      `;
      return;
    }

    // Save to recently viewed
    this.addRecentlyViewed(listing.id);

    const category = window.DataStore.getCategoryBySlug(listing.category) || { name: listing.category, slug: listing.category };
    const images = listing.images && listing.images.length > 0 ? listing.images : ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80'];
    const isSaved = window.DataStore.isWishlisted(listing.id);

    // Breadcrumbs
    const breadcrumbsHtml = `
      <nav class="breadcrumbs">
        <a href="../index.html"><i class="fa-solid fa-house"></i> Home</a>
        <i class="fa-solid fa-chevron-right" style="font-size: 0.65rem;"></i>
        <a href="../categories/${category.slug}.html">${category.name}</a>
        <i class="fa-solid fa-chevron-right" style="font-size: 0.65rem;"></i>
        <span class="current truncate">${listing.title}</span>
      </nav>
    `;

    // Gallery Thumbnails
    let thumbsHtml = '';
    images.forEach((img, index) => {
      thumbsHtml += `
        <div class="thumb-item ${index === 0 ? 'active' : ''}" data-index="${index}" data-src="${img}">
          <img src="${img}" alt="Thumbnail ${index + 1}">
        </div>
      `;
    });

    // Specifications Grid
    let specsHtml = '';
    if (listing.specs && Object.keys(listing.specs).length > 0) {
      specsHtml += `<div class="specs-grid">`;
      for (const [key, val] of Object.entries(listing.specs)) {
        // Format camelCase key to readable words
        const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        specsHtml += `
          <div class="spec-item">
            <span class="spec-label">${label}</span>
            <span class="spec-val">${val}</span>
          </div>
        `;
      }
      specsHtml += `</div>`;
    }

    // Full Details HTML Layout
    container.innerHTML = `
      ${breadcrumbsHtml}
      <div class="details-layout">
        <!-- Left Column: Gallery & Details -->
        <div class="details-left">
          <!-- Gallery -->
          <div class="gallery-container">
            <div class="main-image-view" id="main-gallery-view">
              <img id="active-gallery-img" src="${images[0]}" alt="${listing.title}">
              <button class="btn btn-sm btn-secondary" style="position: absolute; bottom: 12px; right: 12px; background: rgba(0,0,0,0.6); color: #fff; border: none;" onclick="window.Modal.openLightbox(document.getElementById('active-gallery-img').src)">
                <i class="fa-solid fa-expand"></i> Fullscreen
              </button>
            </div>
            ${images.length > 1 ? `<div class="thumbnails-strip">${thumbsHtml}</div>` : ''}
          </div>

          <!-- Description Block -->
          <div style="background: var(--bg-surface); border: 1px solid var(--border-color); border-radius: var(--border-radius-md); padding: 1.5rem; margin-top: 1.5rem;">
            <h3 style="margin-bottom: 0.75rem;">Description</h3>
            <p style="white-space: pre-line; line-height: 1.6; color: var(--text-primary);">${listing.description || 'No detailed description provided.'}</p>
            
            ${specsHtml ? `<h4 style="margin-top: 1.5rem; margin-bottom: 0.5rem;">Key Specifications</h4>${specsHtml}` : ''}
          </div>

          <!-- Location & Map Mockup -->
          <div style="background: var(--bg-surface); border: 1px solid var(--border-color); border-radius: var(--border-radius-md); padding: 1.5rem; margin-top: 1.5rem;">
            <h3 style="margin-bottom: 0.75rem;"><i class="fa-solid fa-location-dot"></i> Location</h3>
            <p style="font-weight: 600; color: var(--text-primary); margin-bottom: 0.75rem;">${listing.locality ? listing.locality + ', ' : ''}${listing.location}</p>
            <div style="width: 100%; height: 160px; background: #e0e6ed; border-radius: var(--border-radius-sm); display: flex; align-items: center; justify-content: center; color: var(--text-secondary); border: 1px dashed var(--border-color);">
              <i class="fa-solid fa-map-location-dot" style="font-size: 2rem; margin-right: 0.5rem;"></i>
              <span>Interactive Map View (${listing.location})</span>
            </div>
          </div>
        </div>

        <!-- Right Column: Price & Seller Card -->
        <div class="details-right" style="display: flex; flex-direction: column; gap: 1.25rem;">
          <!-- Price Card -->
          <div class="seller-box">
            <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 0.5rem;">
              <div style="font-size: 2rem; font-weight: 900; color: var(--color-primary);">${listing.formattedPrice}</div>
              <div style="display: flex; gap: 0.5rem;">
                <button class="card-heart-btn ${isSaved ? 'active' : ''}" style="position: static;" onclick="window.Wishlist.toggle('${listing.id}')">
                  <i class="${isSaved ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i>
                </button>
                <button class="card-heart-btn" style="position: static;" onclick='window.Modal.openShareModal(${JSON.stringify(listing)})'>
                  <i class="fa-solid fa-share-nodes"></i>
                </button>
              </div>
            </div>
            <h1 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.75rem;">${listing.title}</h1>
            <div style="font-size: 0.8rem; color: var(--text-muted); display: flex; justify-content: space-between; border-top: 1px solid var(--border-color-light); padding-top: 0.5rem;">
              <span>${listing.locality || listing.location}</span>
              <span>Posted: ${listing.postedDate}</span>
            </div>
          </div>

          <!-- Seller Profile Card -->
          <div class="seller-box">
            <h4 style="margin-bottom: 1rem;">Seller Information</h4>
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.25rem;">
              <img src="${listing.seller?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}" class="seller-avatar-lg" alt="Seller">
              <div>
                <div style="font-weight: 700; font-size: 1.05rem;">${listing.seller?.name || 'OLX Member'}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">Member since ${listing.seller?.memberSince || '2023'}</div>
                ${listing.seller?.verified ? '<div style="color: var(--color-success); font-size: 0.8rem; font-weight: 600;"><i class="fa-solid fa-circle-check"></i> Verified Profile</div>' : ''}
              </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
              <button class="btn btn-primary btn-block btn-lg" onclick='window.Modal.openChatModal(${JSON.stringify(listing)})'>
                <i class="fa-solid fa-comments"></i> Chat with Seller
              </button>
              <button class="btn btn-secondary btn-block btn-lg" onclick='window.Modal.openContactModal(${JSON.stringify(listing)})'>
                <i class="fa-solid fa-phone"></i> Show Contact Number
              </button>
            </div>
          </div>

          <!-- Safety Tips -->
          <div class="seller-box" style="background: #fff8e1; border-color: #ffe082;">
            <h4 style="color: #b78103; font-size: 0.95rem; margin-bottom: 0.5rem;">
              <i class="fa-solid fa-shield-halved"></i> Safety Warning
            </h4>
            <ul style="font-size: 0.8rem; color: #6d4c41; display: flex; flex-direction: column; gap: 0.35rem;">
              <li>• Meet seller at a safe public location</li>
              <li>• Check item before making any payment</li>
              <li>• Beware of unrealistically low prices</li>
            </ul>
            <button class="btn btn-sm" style="color: var(--color-danger); padding: 0.5rem 0; font-size: 0.8rem; font-weight: 700;" onclick='window.Modal.openReportModal(${JSON.stringify(listing)})'>
              <i class="fa-solid fa-flag"></i> Report this ad
            </button>
          </div>
        </div>
      </div>

      <!-- Related Listings -->
      <div style="margin-top: 3rem;">
        <h2 style="margin-bottom: 1.25rem;">Related Listings in ${category.name}</h2>
        <div class="grid-listings" id="related-listings-grid"></div>
      </div>
    `;

    // Bind Gallery Thumbnail Clicks
    const activeImg = document.getElementById('active-gallery-img');
    document.querySelectorAll('.thumb-item').forEach(thumb => {
      thumb.addEventListener('click', () => {
        document.querySelectorAll('.thumb-item').forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        const src = thumb.getAttribute('data-src');
        if (activeImg) activeImg.src = src;
      });
    });

    // Render Related Listings
    const relatedGrid = document.getElementById('related-listings-grid');
    if (relatedGrid) {
      const allListings = window.DataStore.getListings();
      const related = allListings.filter(item => item.category === listing.category && item.id !== listing.id).slice(0, 4);
      if (related.length > 0) {
        let relHtml = '';
        related.forEach(item => {
          relHtml += this.createCardHtml(item);
        });
        relatedGrid.innerHTML = relHtml;
      } else {
        relatedGrid.innerHTML = `<p style="color: var(--text-muted); grid-column: 1 / -1;">No other active listings found in this category.</p>`;
      }
    }
  },

  addRecentlyViewed(id) {
    try {
      let recent = JSON.parse(localStorage.getItem('olx_recently_viewed')) || [];
      recent = recent.filter(item => item !== id);
      recent.unshift(id);
      recent = recent.slice(0, 6);
      localStorage.setItem('olx_recently_viewed', JSON.stringify(recent));
    } catch (e) {}
  },

  renderRecentlyViewed(containerId = 'recently-viewed-grid') {
    const container = document.getElementById(containerId);
    if (!container) return;

    try {
      const recentIds = JSON.parse(localStorage.getItem('olx_recently_viewed')) || [];
      if (recentIds.length === 0) {
        const section = container.closest('.recently-viewed-section');
        if (section) section.style.display = 'none';
        return;
      }

      const allListings = window.DataStore.getListings();
      const items = recentIds.map(id => allListings.find(l => l.id === id)).filter(Boolean);

      if (items.length === 0) {
        const section = container.closest('.recently-viewed-section');
        if (section) section.style.display = 'none';
        return;
      }

      let html = '';
      items.forEach(item => {
        html += this.createCardHtml(item);
      });
      container.innerHTML = html;
    } catch (e) {}
  }
};

window.Listings = Listings;
