/**
 * OLX Global Search & Autocomplete Module
 * Handles location filtering, keyword queries, search suggestions, and recent searches.
 */

const Search = {
  selectedLocation: 'All India',

  init() {
    this.bindLocationEvents();
    this.bindSearchEvents();
  },

  bindLocationEvents() {
    const locBtn = document.getElementById('header-location-btn');
    const locDropdown = document.getElementById('header-location-dropdown');
    const locText = document.getElementById('selected-location-text');

    if (locBtn && locDropdown) {
      locBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        locDropdown.classList.toggle('active');
      });

      // Populate popular locations
      const locations = window.DataStore.getLocations();
      let locHtml = `
        <div class="location-option" data-loc="All India">
          <i class="fa-solid fa-earth-asia"></i> <strong>All India</strong>
        </div>
      `;
      locations.forEach(loc => {
        locHtml += `
          <div class="location-option" data-loc="${loc}">
            <i class="fa-solid fa-location-dot"></i> ${loc}
          </div>
        `;
      });
      locDropdown.innerHTML = locHtml;

      locDropdown.addEventListener('click', (e) => {
        const option = e.target.closest('.location-option');
        if (option) {
          const loc = option.getAttribute('data-loc');
          this.selectedLocation = loc;
          if (locText) locText.textContent = loc;
          locDropdown.classList.remove('active');
          this.triggerSearch();
        }
      });

      document.addEventListener('click', (e) => {
        if (!locBtn.contains(e.target) && !locDropdown.contains(e.target)) {
          locDropdown.classList.remove('active');
        }
      });
    }
  },

  bindSearchEvents() {
    const searchInput = document.getElementById('global-search-input');
    const searchBtn = document.getElementById('global-search-btn');
    const suggestionsBox = document.getElementById('search-suggestions-box');

    if (!searchInput) return;

    searchInput.addEventListener('input', (e) => {
      const term = e.target.value.trim();
      if (term.length > 0) {
        this.renderSuggestions(term, suggestionsBox);
      } else {
        this.renderRecentSearches(suggestionsBox);
      }
    });

    searchInput.addEventListener('focus', () => {
      const term = searchInput.value.trim();
      if (term.length > 0) {
        this.renderSuggestions(term, suggestionsBox);
      } else {
        this.renderRecentSearches(suggestionsBox);
      }
    });

    if (searchBtn) {
      searchBtn.addEventListener('click', () => {
        this.executeSearch(searchInput.value);
      });
    }

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.executeSearch(searchInput.value);
      }
    });

    document.addEventListener('click', (e) => {
      if (suggestionsBox && !searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
        suggestionsBox.classList.remove('active');
      }
    });
  },

  renderRecentSearches(box) {
    if (!box) return;
    const recents = window.DataStore.getRecentSearches();
    if (recents.length === 0) {
      box.classList.remove('active');
      return;
    }

    let html = `
      <div class="suggestion-section">
        <div class="suggestion-title"><i class="fa-solid fa-clock-rotate-left"></i> Recent Searches</div>
    `;
    recents.forEach(term => {
      html += `
        <div class="suggestion-item" data-search-term="${term}">
          <i class="fa-solid fa-magnifying-glass" style="color: var(--text-muted);"></i>
          <span>${term}</span>
        </div>
      `;
    });
    html += `</div>`;

    box.innerHTML = html;
    box.classList.add('active');
    this.bindSuggestionClicks(box);
  },

  renderSuggestions(term, box) {
    if (!box) return;
    const listings = window.DataStore.getListings();
    const categories = window.DataStore.getCategories();
    const lowerTerm = term.toLowerCase();

    // Match in listings
    const matchedListings = listings.filter(l => 
      l.title.toLowerCase().includes(lowerTerm) || 
      l.category.toLowerCase().includes(lowerTerm)
    ).slice(0, 5);

    // Match in categories
    const matchedCategories = categories.filter(c => 
      c.name.toLowerCase().includes(lowerTerm)
    ).slice(0, 3);

    if (matchedListings.length === 0 && matchedCategories.length === 0) {
      box.innerHTML = `
        <div class="suggestion-section" style="padding: 1rem; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
          No direct suggestions found for "${term}"
        </div>
      `;
      box.classList.add('active');
      return;
    }

    let html = `<div class="suggestion-section">`;

    if (matchedCategories.length > 0) {
      html += `<div class="suggestion-title"><i class="fa-solid fa-tags"></i> Categories</div>`;
      matchedCategories.forEach(cat => {
        html += `
          <div class="suggestion-item" data-category-slug="${cat.slug}">
            <i class="${cat.icon}" style="color: var(--color-primary);"></i>
            <span><strong>${cat.name}</strong></span>
          </div>
        `;
      });
    }

    if (matchedListings.length > 0) {
      html += `<div class="suggestion-title"><i class="fa-solid fa-list"></i> Matching Ads</div>`;
      matchedListings.forEach(l => {
        html += `
          <div class="suggestion-item" data-search-term="${l.title}">
            <i class="fa-solid fa-magnifying-glass" style="color: var(--text-muted);"></i>
            <span>${l.title}</span>
            <span style="margin-left: auto; font-weight: 700; color: var(--color-primary);">${l.formattedPrice}</span>
          </div>
        `;
      });
    }

    html += `</div>`;
    box.innerHTML = html;
    box.classList.add('active');
    this.bindSuggestionClicks(box);
  },

  bindSuggestionClicks(box) {
    box.querySelectorAll('.suggestion-item').forEach(item => {
      item.addEventListener('click', () => {
        const catSlug = item.getAttribute('data-category-slug');
        const term = item.getAttribute('data-search-term');

        if (catSlug) {
          window.location.href = `${window.App.getBasePath()}categories/${catSlug}.html`;
        } else if (term) {
          const searchInput = document.getElementById('global-search-input');
          if (searchInput) searchInput.value = term;
          this.executeSearch(term);
        }
        box.classList.remove('active');
      });
    });
  },

  executeSearch(term) {
    const cleanTerm = (term || '').trim();
    if (cleanTerm) {
      window.DataStore.addRecentSearch(cleanTerm);
    }

    const currentPath = window.location.pathname;
    const isCategoryPage = currentPath.includes('/categories/');
    const isHomePage = currentPath.endsWith('index.html') || currentPath.endsWith('/');

    // If on homepage or search, we can filter listings dynamically
    if (window.Filters && typeof window.Filters.applyFilters === 'function') {
      window.Filters.applyFilters();
    } else {
      // Redirect to homepage or general listing view with query params
      const basePath = window.App.getBasePath();
      let url = `${basePath}index.html?q=${encodeURIComponent(cleanTerm)}`;
      if (this.selectedLocation && this.selectedLocation !== 'All India') {
        url += `&loc=${encodeURIComponent(this.selectedLocation)}`;
      }
      window.location.href = url;
    }
  },

  triggerSearch() {
    if (window.Filters && typeof window.Filters.applyFilters === 'function') {
      window.Filters.applyFilters();
    }
  },

  getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    return {
      query: params.get('q') || '',
      category: params.get('cat') || '',
      subcategory: params.get('sub') || '',
      location: params.get('loc') || '',
      minPrice: params.get('min_price') || '',
      maxPrice: params.get('max_price') || '',
      sort: params.get('sort') || 'newest',
      id: params.get('id') || ''
    };
  }
};

window.Search = Search;
